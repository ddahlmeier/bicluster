clear all;
A = load('AllBiClustersAllClasses_2_LEU_Dudoit');
A = A.AllBiClustersAllClasses;
lA = length(A);
for Algorithm=1:lA
    lA1 = length(A{Algorithm});
    for Parameter=1:lA1
        lA2 = length(A{Algorithm}{Parameter});
        for Selection=1:lA2
            [lA3 lA4] = size(A{Algorithm}{Parameter}{Selection});
            for RefGene=1:lA3
                for Class=1:lA4
                    temp1 = A{Algorithm}{Parameter}{Selection}{RefGene, Class}{1}(1);
                    temp2 = A{Algorithm}{Parameter}{Selection}{RefGene, Class}{2}(1);
                    if (temp1 == -100 || temp1 == 0 || temp2 == -100 || temp2 == 0)
                        disp(strcat(strcat(strcat(strcat(strcat(strcat('Algorithm : ', int2str(Algorithm)), strcat(' Parameter : ', int2str(Parameter))), strcat(' Selection : ', int2str(Selection))), strcat(' RefGene : ', int2str(RefGene))), strcat(' Class : ', int2str(Class))), strcat(strcat(' temp1 : ', int2str(temp1)), strcat(' temp2 : ', int2str(temp2)))))
                        disp('Some gudbad in AllBiClustersAllClasses_2_LEU_Dudoit')
                    end
                end
            end
        end
    end
end

clear all;
A = load('AllBiClustersAllClasses_2_Prostate_Tumor_Singh');
A = A.AllBiClustersAllClasses;
lA = length(A);
for Algorithm=1:lA
    lA1 = length(A{Algorithm});
    for Parameter=1:lA1
        lA2 = length(A{Algorithm}{Parameter});
        for Selection=1:lA2
            [lA3 lA4] = size(A{Algorithm}{Parameter}{Selection});
            for RefGene=1:lA3
                for Class=1:lA4
                    temp1 = A{Algorithm}{Parameter}{Selection}{RefGene, Class}{1}(1);
                    temp2 = A{Algorithm}{Parameter}{Selection}{RefGene, Class}{2}(1);
                    if (temp1 == -100 || temp1 == 0 || temp2 == -100 || temp2 == 0)
                        disp(strcat(strcat(strcat(strcat(strcat(strcat('Algorithm : ', int2str(Algorithm)), strcat(' Parameter : ', int2str(Parameter))), strcat(' Selection : ', int2str(Selection))), strcat(' RefGene : ', int2str(RefGene))), strcat(' Class : ', int2str(Class))), strcat(strcat(' temp1 : ', int2str(temp1)), strcat(' temp2 : ', int2str(temp2)))))
                        disp('Some gudbad in AllBiClustersAllClasses_2_Prostate_Tumor_Singh')
                    end
                end
            end
        end
    end
end

clear all;
A = load('AllBiClustersAllClasses_4_Brain_Tumor_Nutt');
A = A.AllBiClustersAllClasses;
lA = length(A);
for Algorithm=1:lA
    lA1 = length(A{Algorithm});
    for Parameter=1:lA1
        lA2 = length(A{Algorithm}{Parameter});
        for Selection=1:lA2
            [lA3 lA4] = size(A{Algorithm}{Parameter}{Selection});
            for RefGene=1:lA3
                for Class=1:lA4
                    temp1 = A{Algorithm}{Parameter}{Selection}{RefGene, Class}{1}(1);
                    temp2 = A{Algorithm}{Parameter}{Selection}{RefGene, Class}{2}(1);
                    if (temp1 == -100 || temp1 == 0 || temp2 == -100 || temp2 == 0)
                        disp(strcat(strcat(strcat(strcat(strcat(strcat('Algorithm : ', int2str(Algorithm)), strcat(' Parameter : ', int2str(Parameter))), strcat(' Selection : ', int2str(Selection))), strcat(' RefGene : ', int2str(RefGene))), strcat(' Class : ', int2str(Class))), strcat(strcat(' temp1 : ', int2str(temp1)), strcat(' temp2 : ', int2str(temp2)))))
                        disp('Some gudbad in AllBiClustersAllClasses_4_Brain_Tumor_Nutt')
                    end
                end
            end
        end
    end
end

clear all;
A = load('AllBiClustersAllClasses_5_Brain_Tumor_Pomeroy');
A = A.AllBiClustersAllClasses;
lA = length(A);
for Algorithm=1:lA
    lA1 = length(A{Algorithm});
    for Parameter=1:lA1
        lA2 = length(A{Algorithm}{Parameter});
        for Selection=1:lA2
            [lA3 lA4] = size(A{Algorithm}{Parameter}{Selection});
            for RefGene=1:lA3
                for Class=1:lA4
                    temp1 = A{Algorithm}{Parameter}{Selection}{RefGene, Class}{1}(1);
                    temp2 = A{Algorithm}{Parameter}{Selection}{RefGene, Class}{2}(1);
                    if (temp1 == -100 || temp1 == 0 || temp2 == -100 || temp2 == 0)
                        disp(strcat(strcat(strcat(strcat(strcat(strcat('Algorithm : ', int2str(Algorithm)), strcat(' Parameter : ', int2str(Parameter))), strcat(' Selection : ', int2str(Selection))), strcat(' RefGene : ', int2str(RefGene))), strcat(' Class : ', int2str(Class))), strcat(strcat(' temp1 : ', int2str(temp1)), strcat(' temp2 : ', int2str(temp2)))))
                        disp('Some gudbad in AllBiClustersAllClasses_5_Brain_Tumor_Pomeroy')
                    end
                end
            end
        end
    end
end

clear all;
A = load('AllBiClustersAllClasses_11_Tumor_Su');
A = A.AllBiClustersAllClasses;
lA = length(A);
for Algorithm=1:lA
    lA1 = length(A{Algorithm});
    for Parameter=1:lA1
        lA2 = length(A{Algorithm}{Parameter});
        for Selection=1:lA2
            [lA3 lA4] = size(A{Algorithm}{Parameter}{Selection});
            for RefGene=1:lA3
                for Class=1:lA4
                    temp1 = A{Algorithm}{Parameter}{Selection}{RefGene, Class}{1}(1);
                    temp2 = A{Algorithm}{Parameter}{Selection}{RefGene, Class}{2}(1);
                    if (temp1 == -100 || temp1 == 0 || temp2 == -100 || temp2 == 0)
                        disp(strcat(strcat(strcat(strcat(strcat(strcat('Algorithm : ', int2str(Algorithm)), strcat(' Parameter : ', int2str(Parameter))), strcat(' Selection : ', int2str(Selection))), strcat(' RefGene : ', int2str(RefGene))), strcat(' Class : ', int2str(Class))), strcat(strcat(' temp1 : ', int2str(temp1)), strcat(' temp2 : ', int2str(temp2)))))
                        disp('Some gudbad in AllBiClustersAllClasses_11_Tumor_Su')
                    end
                end
            end
        end
    end
end

clear all;
A = load('AllBiClustersAllClasses_14_Tumor_Ramaswamy');
A = A.AllBiClustersAllClasses;
lA = length(A);
for Algorithm=1:lA
    lA1 = length(A{Algorithm});
    for Parameter=1:lA1
        lA2 = length(A{Algorithm}{Parameter});
        for Selection=1:lA2
            [lA3 lA4] = size(A{Algorithm}{Parameter}{Selection});
            for RefGene=1:lA3
                for Class=1:lA4
                    temp1 = A{Algorithm}{Parameter}{Selection}{RefGene, Class}{1}(1);
                    temp2 = A{Algorithm}{Parameter}{Selection}{RefGene, Class}{2}(1);
                    if (temp1 == -100 || temp1 == 0 || temp2 == -100 || temp2 == 0)
                        disp(strcat(strcat(strcat(strcat(strcat(strcat('Algorithm : ', int2str(Algorithm)), strcat(' Parameter : ', int2str(Parameter))), strcat(' Selection : ', int2str(Selection))), strcat(' RefGene : ', int2str(RefGene))), strcat(' Class : ', int2str(Class))), strcat(strcat(' temp1 : ', int2str(temp1)), strcat(' temp2 : ', int2str(temp2)))))
                        disp('Some gudbad in AllBiClustersAllClasses_14_Tumor_Ramaswamy')
                    end
                end
            end
        end
    end
end
