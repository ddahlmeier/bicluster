function [BiRowList BiColList BiCluster] = CCalgorithm1(Matrix, Delta, RowList, ColList, CCalgorithm2)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Program: CCalgorithm1(Matrix, Delta, RowList, ColList, CCalgorithm2)                                                                       %
%   Author: Baljeet Malhotra                                                                                                                   %
%   Date Created: Jan. 30, 2007                                                                                                                %
%   Last modified: Feb. 10, 2007                                                                                                               %
%   Input:                                                                                                                                     %
%   Output:                                                                                                                                    %
%   Example:                                                                                                                                   %
%   Comments: This algorithm does not specify that what should be the Delta value, which would decide the quality of the cluster               %    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

BiRowList = 0;
BiColList = 0;
BiCluster = 0;

OriginalMatrix = Matrix;

[RowSize ColSize] = size(Matrix);

if (CCalgorithm2 ~= 1)
    [RowList ColList] = ComputeRowColList(RowSize, ColSize);
end

ResidueScore = computeResidue(Matrix);

while(ResidueScore > Delta && RowSize > 0 && ColSize > 0) %Start of while loop        
            
        %%%Computing means of all rows
        for i=1:RowSize
            RowMeans(i,1) = mean(Matrix(i,:));
        end

        %%%Computing means of all columns
        for i=1:ColSize
            ColMeans(i,1) = mean(Matrix(:,i));
        end

        %%%Computing mean of the matrix
        MatrixMean = sum(mean(Matrix))/ColSize;

        %%%Finding row with the largest residue score
        LargestSumRow = 0;
        LargestSumRowIndex = 1;
        for i=1:RowSize
            SumRow = 0;
            for j=1:ColSize
                tempCal = (Matrix(i,j) - RowMeans(i,1) - ColMeans(j,1) + MatrixMean)^2;
                SumRow = SumRow + tempCal;
            end
            if((SumRow/ColSize) > LargestSumRow)
                LargestSumRow = SumRow/ColSize;
                LargestSumRowIndex = i;
            end
        end

        %%%Finding column with the largest residue score
        LargestSumCol = 0;
        LargestSumColIndex = 1;
        for i=1:ColSize
            SumCol = 0;
            for j=1:RowSize
                tempCal = (Matrix(j,i) - ColMeans(i,1) - RowMeans(j,1) + MatrixMean)^2;
                SumCol = SumCol + tempCal;
            end
            if((SumCol/RowSize) > LargestSumCol)
                LargestSumCol = SumCol/RowSize;
                LargestSumColIndex = i;
            end
        end

        %%%%Deleting row or column with the largest residue score
        if(LargestSumCol > LargestSumRow)
            Matrix(:,LargestSumColIndex) = [];
            ColList(LargestSumColIndex) = [];
        else
            Matrix(LargestSumRowIndex,:) = [];
            RowList(LargestSumRowIndex) = [];
        end

        ResidueScore = computeResidue(Matrix);
        [RowSize ColSize] = size(Matrix);
    
end %End of while loop

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output BI-CLUSTER ROWS AND COLUMNS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if(RowSize > 0 && ColSize > 0)
    BiRowList = RowList; 
    BiColList = ColList;
    BiCluster = Matrix;
    if (CCalgorithm2 ~= 1)
        BiCluster
        BiClusterInActualMatrix = zeros(size(OriginalMatrix));
        BiClusterInActualMatrix(BiRowList, BiColList) = 100;
        figure;
        image(BiClusterInActualMatrix);
    end    
else
    disp(strcat('RowSize: ',int2str(RowSize)))
    disp(strcat('ColSize: ',int2str(ColSize)))
    disp('Exiting CCalgorithm1: Reason: either all rows or all columns are deleted. Please check the parameters setting.')
end
