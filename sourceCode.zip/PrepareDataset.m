function [AllSamplesAllClasses TotalClasses] = PrepareDataset(DatasetNumber)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Program: RunBiclusterClassification(DatasetNumber)                                                                                                      %
%   Author: Baljeet Malhotra                                                                                                                                %
%   Date Created: Feb. 14, 2007                                                                                                                             %
%   Last modified: Mar. 27, 2007                                                                                                                            %
%   Input:                                                                                                                                                  %
%   Output:                                                                                                                                                 %
%   Example:                                                                                                                                                %
%   Comments: Prepare dataset for the generation of bi-clusters                                                                                             %   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Selection of dataset

if (DatasetNumber == 1)       
    DatasetFileName = '2_LEU_Dudoit'        
elseif (DatasetNumber == 2)    
    DatasetFileName = '2_Prostate_Tumor_Singh'
elseif (DatasetNumber == 3)    
    DatasetFileName = '4_Brain_Tumor_Nutt'
elseif (DatasetNumber == 4)    
    DatasetFileName = '5_Brain_Tumor_Pomeroy'
elseif (DatasetNumber == 5)
    DatasetFileName = '11_Tumor_Su'
elseif (DatasetNumber == 6)
    DatasetFileName = '14_Tumor_Ramaswamy'
elseif (DatasetNumber == 7)
    DatasetFileName = '2_Prognostic_Breast_Cancer'
elseif (DatasetNumber == 8)
    DatasetFileName = '2_Prognostic_AML_ALL'
elseif (DatasetNumber == 9)
    DatasetFileName = '2_Prognostic_Central_Nervous'
elseif (DatasetNumber == 10)
    DatasetFileName = '2_Prognostic_Prostate'
elseif (DatasetNumber == 11)
    DatasetFileName = '2_Diagnostic_Lung_Cancer'
elseif (DatasetNumber == 12)
    DatasetFileName = '2_Diagnostic_AML_ALL'
elseif (DatasetNumber == 13)
    DatasetFileName = '2_Diagnostic_Colon_Tumor'
elseif (DatasetNumber == 14)
    DatasetFileName = '2_Diagnostic_Prostate'
end

%%%% Retreive dataset

Dataset = load(DatasetFileName);
Dataset = Dataset.data;
Dataset = Dataset'; %%%%After transpose (of D) the first row contains the class information
DatasetClassLabels = Dataset(1,:); %%%%Take backup of class labels
Dataset(1,:) = []; %%%%Remove class labels from the dataset

%%%% Make standard class labels (0-13)
TotalClasses = length(unique(DatasetClassLabels));

if (isempty(intersect(unique(DatasetClassLabels), 0)) == 1)
    
    for i=1:length(DatasetClassLabels)
        DatasetClassLabels(i) = DatasetClassLabels(i) - 1;
    end
end
%%%% Retreive the size of dataset

[TotalGenes TotalSamples] = size(Dataset);

%%%Seperate all classes from the dataset

TotalSamplesInClass = zeros(TotalSamples,1);
AllSamplesAllClasses = cell(TotalClasses,1);

for CurrentSample=1:TotalSamples

    if (DatasetClassLabels(1,CurrentSample) == 0)
        TotalSamplesInClass(1) = TotalSamplesInClass(1) + 1;
        AllSamplesAllClasses{1}(:, TotalSamplesInClass(1)) = Dataset(:,CurrentSample);

    elseif (DatasetClassLabels(1,CurrentSample) == 1)
        TotalSamplesInClass(2) = TotalSamplesInClass(2) + 1;
        AllSamplesAllClasses{2}(:, TotalSamplesInClass(2)) = Dataset(:,CurrentSample);
    
    elseif (DatasetClassLabels(1,CurrentSample) == 2)
        TotalSamplesInClass(3) = TotalSamplesInClass(3) + 1;
        AllSamplesAllClasses{3}(:, TotalSamplesInClass(3)) = Dataset(:,CurrentSample);
    
    elseif (DatasetClassLabels(1,CurrentSample) == 3)
        TotalSamplesInClass(4) = TotalSamplesInClass(4) + 1;
        AllSamplesAllClasses{4}(:, TotalSamplesInClass(4)) = Dataset(:,CurrentSample);
    
    elseif (DatasetClassLabels(1,CurrentSample) == 4)
        TotalSamplesInClass(5) = TotalSamplesInClass(5) + 1;
        AllSamplesAllClasses{5}(:, TotalSamplesInClass(5)) = Dataset(:,CurrentSample);
    
    elseif (DatasetClassLabels(1,CurrentSample) == 5)
        TotalSamplesInClass(6) = TotalSamplesInClass(6) + 1;
        AllSamplesAllClasses{6}(:, TotalSamplesInClass(6)) = Dataset(:,CurrentSample);
    
    elseif (DatasetClassLabels(1,CurrentSample) == 6)
        TotalSamplesInClass(7) = TotalSamplesInClass(7) + 1;
        AllSamplesAllClasses{7}(:, TotalSamplesInClass(7)) = Dataset(:,CurrentSample);
    
    elseif (DatasetClassLabels(1,CurrentSample) == 7)
        TotalSamplesInClass(8) = TotalSamplesInClass(8) + 1;
        AllSamplesAllClasses{8}(:, TotalSamplesInClass(8)) = Dataset(:,CurrentSample);
    
    elseif (DatasetClassLabels(1,CurrentSample) == 8)
        TotalSamplesInClass(9) = TotalSamplesInClass(9) + 1;
        AllSamplesAllClasses{9}(:, TotalSamplesInClass(9)) = Dataset(:,CurrentSample);
    
    elseif (DatasetClassLabels(1,CurrentSample) == 9)
        TotalSamplesInClass(10) = TotalSamplesInClass(10) + 1;
        AllSamplesAllClasses{10}(:, TotalSamplesInClass(10)) = Dataset(:,CurrentSample);
    
    elseif (DatasetClassLabels(1,CurrentSample) == 10)
        TotalSamplesInClass(11) = TotalSamplesInClass(11) + 1;
        AllSamplesAllClasses{11}(:, TotalSamplesInClass(11)) = Dataset(:,CurrentSample);
    
    elseif (DatasetClassLabels(1,CurrentSample) == 11)
        TotalSamplesInClass(12) = TotalSamplesInClass(12) + 1;
        AllSamplesAllClasses{12}(:, TotalSamplesInClass(12)) = Dataset(:,CurrentSample);

    elseif (DatasetClassLabels(1,CurrentSample) == 12)
        TotalSamplesInClass(13) = TotalSamplesInClass(13) + 1;
        AllSamplesAllClasses{13}(:, TotalSamplesInClass(13)) = Dataset(:,CurrentSample);

    elseif (DatasetClassLabels(1,CurrentSample) == 13)
        TotalSamplesInClass(14) = TotalSamplesInClass(14) + 1;
        AllSamplesAllClasses{14}(:, TotalSamplesInClass(14)) = Dataset(:,CurrentSample);
        
    elseif (DatasetClassLabels(1,CurrentSample) == 14)
        TotalSamplesInClass(15) = TotalSamplesInClass(15) + 1;
        AllSamplesAllClasses{15}(:, TotalSamplesInClass(15)) = Dataset(:,CurrentSample);

    elseif (DatasetClassLabels(1,CurrentSample) == 15)
        TotalSamplesInClass(16) = TotalSamplesInClass(16) + 1;
        AllSamplesAllClasses{16}(:, TotalSamplesInClass(16)) = Dataset(:,CurrentSample);

    elseif (DatasetClassLabels(1,CurrentSample) == 16)
        TotalSamplesInClass(17) = TotalSamplesInClass(17) + 1;
        AllSamplesAllClasses{17}(:, TotalSamplesInClass(17)) = Dataset(:,CurrentSample);

    elseif (DatasetClassLabels(1,CurrentSample) == 17)
        TotalSamplesInClass(18) = TotalSamplesInClass(18) + 1;
        AllSamplesAllClasses{18}(:, TotalSamplesInClass(18)) = Dataset(:,CurrentSample);

    elseif (DatasetClassLabels(1,CurrentSample) == 18)
        TotalSamplesInClass(19) = TotalSamplesInClass(19) + 1;
        AllSamplesAllClasses{19}(:, TotalSamplesInClass(19)) = Dataset(:,CurrentSample);

    elseif (DatasetClassLabels(1,CurrentSample) == 19)
        TotalSamplesInClass(20) = TotalSamplesInClass(20) + 1;
        AllSamplesAllClasses{20}(:, TotalSamplesInClass(20)) = Dataset(:,CurrentSample);

    elseif (DatasetClassLabels(1,CurrentSample) == 20)
        TotalSamplesInClass(21) = TotalSamplesInClass(21) + 1;
        AllSamplesAllClasses{21}(:, TotalSamplesInClass(21)) = Dataset(:,CurrentSample);

    elseif (DatasetClassLabels(1,CurrentSample) == 21)
        TotalSamplesInClass(22) = TotalSamplesInClass(22) + 1;
        AllSamplesAllClasses{22}(:, TotalSamplesInClass(22)) = Dataset(:,CurrentSample);

    elseif (DatasetClassLabels(1,CurrentSample) == 22)
        TotalSamplesInClass(23) = TotalSamplesInClass(23) + 1;
        AllSamplesAllClasses{23}(:, TotalSamplesInClass(23)) = Dataset(:,CurrentSample);

    elseif (DatasetClassLabels(1,CurrentSample) == 23)
        TotalSamplesInClass(24) = TotalSamplesInClass(24) + 1;
        AllSamplesAllClasses{24}(:, TotalSamplesInClass(24)) = Dataset(:,CurrentSample);

    elseif (DatasetClassLabels(1,CurrentSample) == 24)
        TotalSamplesInClass(25) = TotalSamplesInClass(25) + 1;
        AllSamplesAllClasses{25}(:, TotalSamplesInClass(25)) = Dataset(:,CurrentSample);
        
    elseif (DatasetClassLabels(1,CurrentSample) == 25)
        TotalSamplesInClass(26) = TotalSamplesInClass(26) + 1;
        AllSamplesAllClasses{26}(:, TotalSamplesInClass(26)) = Dataset(:,CurrentSample);

    end

end %%%End of for loop

%%%clear the memory

clear Dataset;
clear TotalSamplesInClass;