function [BiClusterRows BiClusterCols SimilarityMatrix] = MSBalgorithm(Matrix, Alpha, Beta, Gamma, RefGene)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Program: MSBalgorithm(Matrix, Alpha, Beta, Gamma, RefGene)                                                                                              %
%   Author: Baljeet Malhotra                                                                                                                                %
%   Date Created: Jan. 30, 2007                                                                                                                             %
%   Last modified: Feb. 10, 2007                                                                                                                            %
%   Input:                                                                                                                                                  %
%   Output:                                                                                                                                                 %
%   Example:                                                                                                                                                %
%   Comments: Liu and Wang's Maximum Similarity Bicluster Algorithm                                                                                         %   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[Row Col] = size(Matrix);

TrackSimilarityScore = zeros(Row + Col - 2, 2);

SimilarityMatrix = ComputeSimilarityMatrix(Matrix, Alpha, Beta, Gamma, RefGene);

[RowList ColList] = ComputeRowColList(Row, Col);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%(START) COMPUTING ALL BI-CLUSTERS%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for l=1:(Row + Col - 2)
    [RowSimilarity, RowIndex] = min(sum(SimilarityMatrix'));
    [ColSimilarity, ColIndex] = min(sum(SimilarityMatrix));    
    [R C] = size(SimilarityMatrix);
    TrackSimilarityScore(l,1) = sum(sum(SimilarityMatrix))/(R*C); %Average Similarity Score used for Gamma
    RowMap{l} = RowList;
    ColMap{l} = ColList;

    if (RowSimilarity < ColSimilarity)
        TrackSimilarityScore(l,2) = RowSimilarity; 
        SimilarityMatrix(RowIndex,:) = [];
        RowList(RowIndex) = [];
        
    else
        TrackSimilarityScore(l,2) = ColSimilarity;
        SimilarityMatrix(:,ColIndex) = [];
        ColList(ColIndex) = [];
        
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%(END) COMPUTING ALL BI-CLUSTERS%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%(START) SELECTING BI-CLUSTERS WITH AVERAGE SIMILARITY SCORE NOT LESS THAN GAMMA %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tempIndex = 1;
tempGamma = TrackSimilarityScore(tempIndex,1);
while(tempGamma < Gamma && tempIndex < (Row + Col - 2))
    tempIndex = tempIndex + 1;
    [tempGamma] = TrackSimilarityScore(tempIndex,1);
end

%%%%%%%%%%%%%%%%%(END) SELECTING BI-CLUSTERS WITH AVERAGE SIMILARITY SCORE NOT LESS THAN GAMMA %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%(START) SELECTING BI-CLUSTERS WITH MAXIMUM SIMILARITY FROM THE BI-CLUSTERS CHOSEN DURING THE PREVIOUS STEP%%%%%%%%%%%%

[ClusterScore] = max(TrackSimilarityScore(tempIndex:(Row + Col - 2),2));

tempIndex = 1;
[tempClusterScore] = TrackSimilarityScore(tempIndex,2);
while(tempClusterScore ~= ClusterScore && tempIndex < (Row + Col - 2))
    tempIndex = tempIndex + 1;
    [tempClusterScore] = TrackSimilarityScore(tempIndex,2);
end

%%%%%%%%%%%%%%%%(END) SELECTING BI-CLUSTERS WITH MAXIMUM SIMILARITY FROM THE BI-CLUSTERS CHOSEN DURING THE PREVIOUS STEP%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%(START) SELECTING THE FINAL BI-CLUSTER%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

BiClusterRows = RowMap{tempIndex};
BiClusterCols = ColMap{tempIndex};
BiClusterInActualMatrix = zeros(size(Matrix));
BiClusterInActualMatrix(BiClusterRows, BiClusterCols) = 100;
% figure;
% title (strcat('Gene :', int2str(RefGene)))
% image(BiClusterInActualMatrix);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%(END) SELECTING THE FINAL BI-CLUSTER%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%