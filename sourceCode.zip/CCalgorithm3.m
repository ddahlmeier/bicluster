function [NewBiRowList NewBiColList NewBiCluster] = CCalgorithm3(Matrix, Delta, Alpha, Algorithm)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Program: CCalgorithm1(Matrix, Delta, Alpha, Algorithm)                                                                                                  %
%   Author: Baljeet Malhotra                                                                                                                                %
%   Date Created: Jan. 30, 2007                                                                                                                             %
%   Last modified: Feb. 10, 2007                                                                                                                            %
%   Input:                                                                                                                                                  %
%   Output:                                                                                                                                                 %
%   Example:                                                                                                                                                %
%   Comments:                                                                                                                                               %   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

NewBiRowList = 0;
NewBiColList = 0;
NewBiCluster = 0;

if (Algorithm == 1)
    [BiRowList BiColList BiCluster] = CCalgorithm1(Matrix, Delta, 0, 0, 0); 
end

if (Algorithm == 2)
    [BiRowList BiColList BiCluster] = CCalgorithm2(Matrix, Delta, Alpha, 1);
end

[BiRowSize BiColSize] = size(BiCluster);

%%%Computing means of all rows
for i=1:BiRowSize
    RowMeans(i) = mean(BiCluster(i,:));
end

%%%Computing means of all columns
for i=1:BiColSize
    ColMeans(i) = mean(BiCluster(:,i));
end

%%%Computing mean of the bicluster
BiClusterMean = sum(mean(BiCluster))/ColSize;

%%%Computing residueScore of the bicluster
ResidueScore = computeResidue(BiCluster);

[Row Col] = size(Matrix);

for i=1:Col
    SumRow = 0;
    tempCol = intersect(BiColList, i);
    if (isempty(tempCol))

        Mean1 = 0;
        for j=1:length(BiRowList)
            Mean1 = Mean1 + Matrix(BiRowList(j), i);
        end

        Mean2 = 0;
        for j=1:length(tempCol)
            Mean1 = Mean1 + Matrix(tempCol(j);
        end
    end
end


for i=1:length(BiRowList)
    
    
    