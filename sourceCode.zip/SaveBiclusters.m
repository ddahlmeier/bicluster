function [AllBiClustersAllClasses] = SaveBiclusters(UpdatingBiclusters, AlgorithmSelection, VaryingParameter, ParameterSelection, StartingReferenceGene, TotalReferenceGenes,TotalClasses,AllBiClustersAllClasses,tempData)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Program: SaveBiclusters(UpdatingBiclusters, AlgorithmSelection, VaryingParameter, ParameterSelection, StartingReferenceGene, TotalReferenceGenes,TotalClasses,AllBiClustersAllClasses,tempData)  %
%   Author: Baljeet Malhotra                                                                                                                                                                         %
%   Date Created: July 5, 2007                                                                                                                                                                       %
%   Last modified: July 7, 2007                                                                                                                                                                      %
%   Input:                                                                                                                                                                                           %
%   Output:                                                                                                                                                                                          %
%   Example:                                                                                                                                                                                         %
%   Comments:                                                                                                                                                                                        %   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

EndReferenceGene = StartingReferenceGene + TotalReferenceGenes - 1;
for CurrentClass=1:TotalClasses
    [TotalPatients TotalRefGenes] = size(AllBiClustersAllClasses{CurrentClass});
    for CurrentPatient=1:TotalPatients
        RefGeneIndex = 1;
        for CurrentReferenceGene=StartingReferenceGene:EndReferenceGene
            tempData{AlgorithmSelection}{VaryingParameter}{ParameterSelection}{CurrentClass}{CurrentPatient,CurrentReferenceGene} = AllBiClustersAllClasses{CurrentClass}{CurrentPatient,RefGeneIndex};
            RefGeneIndex = RefGeneIndex + 1;        
        end
    end
end   
AllBiClustersAllClasses = tempData;