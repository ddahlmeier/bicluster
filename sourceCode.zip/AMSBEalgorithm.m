function [BiClusterRows, BiClusterCols] = AMSBEalgorithm(Matrix, Alpha, Beta, Gamma, GammaE, RefGene, RefCond)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Program: MSBEalgorithm(Matrix, Alpha, Beta, Gamma, GammaE, RefGene, RefCond)                          %
%   Author: Baljeet Malhotra                                                                              %
%   Date Created: Jan. 30, 2007                                                                           %
%   Last modified: Feb. 10, 2007                                                                          %
%   Input:                                                                                                %
%   Output:                                                                                               %
%   Example:                                                                                              %
%   Comments: Liu and Wang's Maximum Similarity Algorithm for Additive Biclusters (3)                     %   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[Row Col] = size(Matrix);
NewMatrix = zeros(size(Matrix));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%(START) BI-CLUSTER %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i=1:Row
    for j=1:Col
        NewMatrix(i,j) = Matrix(i,j) - (Matrix(i, RefCond) - Matrix(RefGene, RefCond));
    end
end

[BiClusterRows BiClusterCols] = MSBEalgorithm(NewMatrix, Alpha, Beta, Gamma, GammaE, RefGene);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%(END) BI-CLUSTER %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

BiClusterInActualMatrix = zeros(size(Matrix));
BiClusterInActualMatrix(BiClusterRows, BiClusterCols) = 100;
figure;
image(BiClusterInActualMatrix);
