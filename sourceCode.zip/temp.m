a = [100 98.6 
    88 80
    85.6 93.5];
figure1 = figure; 
axes1 = axes(...
  'CameraUpVector',[0 1 0],...
  'XTick',[1 2 3],...
  'XTickLabel',{'Leukemia (2 classes)', 'Tumor (4 classes)', 'Carcinomas (11 classes)'},...
  'Parent',figure1);
box('on');
hold('all');
bar(a);
title('Comparision of best classification results achieved with BICLAM using three different datasets ');
xlabel('Datasets');
ylabel('Accuracy Rate (% of total testing samples)');
legend('BICCLAM(A1,D1)', 'Cai-DBM', 'Location','Best', 'Orientation', 'verticle');
exportfig(gcf, 'ClassificationComparisionWithOthers.eps', 'FontMode', 'fixed', 'FontSize', 12, 'color', 'cmyk' );    

a = [100.00 095.83 098.66 065.17 098.66
     088.00 066.00 072.00 072.00 080.00   
     085.60 065.20 048.00 045.00 093.50];
figure1 = figure; 
axes1 = axes(...
  'CameraUpVector',[0 1 0],...
  'XTick',[1 2 3],...
  'XTickLabel',{'Leukemia (2 classes)', 'Tumor (4 classes)', 'Carcinomas (11 classes)'},...
  'Parent',figure1);
box('on');
hold('all');
bar(a);
title('Comparision of classification results achieved with different BICCLAM settings');
xlabel('Datasets');
ylabel('Leave one out accuracy (%)');
legend('BICCLAM1(A1,D1)', 'BICCLAM2(A1,D2)', 'BICCLAM3(A2,D1)', 'BICCLAM4(A2,D2)', 'Cai-DBM', 'Location','Best', 'Orientation', 'verticle');
exportfig(gcf, 'AllClassificationResults.eps', 'FontMode', 'fixed', 'FontSize', 12, 'color', 'cmyk' );    

a = [100 95.83 
    88 66
    85.6 65.2];
figure1 = figure; 
axes1 = axes(...
  'CameraUpVector',[0 1 0],...
  'XTick',[1 2 3],...
  'XTickLabel',{'Leukemia (2 classes)', 'Tumor (4 classes)', 'Carcinomas (11 classes)'},...
  'Parent',figure1);
box('on');
hold('all');
bar(a);
title('Comparision of two distance calculation techniques in BICCLAM');
xlabel('Datasets');
ylabel('Leave one out accuracy (%)');
legend('Technique-1 (Eq.1)', 'Technique-2 (Eq.2)', 'Location','Best', 'Orientation', 'verticle');
exportfig(gcf, 'ClassificationComparisionDistanceCalculationTechnqiues.eps', 'FontMode', 'fixed', 'FontSize', 12, 'color', 'cmyk' );    

figure1 = figure; 
box('on');
hold('all');
bar(temp);
title('Classification accuracy with increasing number of representative bi-clusters');
xlabel('Noumber of representative bi-clusters');
ylabel('Classification Accuracy (%)');
exportfig(gcf, 'ClassificationAccuracyWithVaryingBiclustersCarcinomasDataset.eps', 'FontMode', 'fixed', 'FontSize', 12, 'color', 'cmyk' );

figure1 = figure; 
box('on');
hold('all');
bar(temp);
title('Classification accuracy with increasing number of representative bi-clusters');
xlabel('Noumber of representative bi-clusters');
ylabel('Classification Accuracy (%)');
exportfig(gcf, 'ClassificationAccuracyWithVaryingBiclustersTumorDataset.eps', 'FontMode', 'fixed', 'FontSize', 12, 'color', 'cmyk' );

GenerateBiclusters(5,2,1,7,1,1,0,1.10,0.50,1.2)

%%%%For LEU data
%%% Distance 1
for i=1:19
    [T C] = RunBiclusterClassification(1,1,1,4,1,1,i,1);
    temp(i) = C;
end

max(temp)

%%% Distance 2
for i=1:19
    [T C] = RunBiclusterClassification(1,1,1,4,2,1,i,1);
    temp(i) = C;
end

max(temp)

%For LEU data

%%% Distance 1
for i=1:40
    [T C] = RunBiclusterClassification(3,1,1,5,1,1,i,1);
    temp(i) = C;
end

%%% Distance 2
for i=1:40
    [T C] = RunBiclusterClassification(3,1,1,5,2,1,i,1);
    temp(i) = C;
end




save tempResult.mat temp -mat;

    
