function [] = GenerateBiclusters(DatasetNumber, AlgorithmSelection, VaryingParameter, ParameterSelection, StartingReferenceGene, TotalReferenceGenes, UpdatingBiclusters, Alpha, Beta, Gamma)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Program: GenerateBiclusters(DatasetNumber, AlgorithmSelection, VaryingParameter, ParameterSelection, StartingReferenceGene, TotalReferenceGenes, UpdatingBiclusters, Alpha, Beta, Gamma)    %
%   Author: Baljeet Malhotra                                                                                                                                                                    %
%   Date Created: Feb. 14, 2007                                                                                                                                                                 %
%   Last modified: Mar. 27, 2007                                                                                                                                                                %
%   Input:                                                                                                                                                                                      %
%   Output:                                                                                                                                                                                     %
%   Example:                                                                                                                                                                                    %
%   Comments: Generate bi-clusters using Liu and Wang's Maximum Similarity Bicluster Algorithm and Cheng and Church's algorithm                                                                 %    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Selection of dataset by calling PrepareDataset program;

[AllSamplesAllClasses TotalClasses] = PrepareDataset(DatasetNumber);

if (UpdatingBiclusters ~= 100)
    %%%Select the starting reference gene by calling
    %%%PrepareReferenceGenesSelection program
    [StartingReferenceGene] = PrepareReferenceGenesSelection(DatasetNumber, AlgorithmSelection, VaryingParameter, ParameterSelection);
    disp(strcat('Starting ref gene is  : ', int2str(StartingReferenceGene)))
end
EndReferenceGene = StartingReferenceGene + TotalReferenceGenes - 1;

%%%Start of bi-cluster generation

AllBiClustersAllClasses = cell(TotalClasses, 1);

if (AlgorithmSelection == 2)
    StartingReferenceGene = 1;
    EndReferenceGene = 1;
end
    
%%%Compute biclusters w.r.t to each class
for CurrentClass=1:TotalClasses

    [TotalGenes TotalPatients] = size(AllSamplesAllClasses{CurrentClass});

    %%%Compute biclusters w.r.t to each patient
    for CurrentPatient=1:TotalPatients+1

        CurrentDataSet = AllSamplesAllClasses{CurrentClass};
        
        if (CurrentPatient <= TotalPatients)
            CurrentDataSet(:, CurrentPatient) = [];
        end

        RefGeneIndex = 1;

        %%%Compute biclusters w.r.t given set of fererence genes
        for CurrentReferenceGene=StartingReferenceGene:EndReferenceGene

            %%%Select the reference gene 
            %RefGene = ceil(rand*TotalGenes-1);
            RefGene = CurrentReferenceGene;
                        
            disp(strcat(strcat(strcat(strcat(strcat(strcat('Algorithm : ', int2str(AlgorithmSelection)), strcat(' Parameter : ', int2str(VaryingParameter))), strcat(' Selection : ', int2str(ParameterSelection))), strcat(strcat(' Class : ', int2str(CurrentClass)), strcat(' Patient : ', int2str(CurrentPatient)))), strcat(' RefGene : ', int2str(CurrentReferenceGene))), strcat(strcat(' Updating : ', int2str(UpdatingBiclusters)), strcat(' Dataset : ', int2str(DatasetNumber)))))

            if (AlgorithmSelection == 1)

                [BiCluster{1} BiCluster{2}] = MSBalgorithm(CurrentDataSet, Alpha, Beta, Gamma, RefGene);
                
                %%%%Adjust the columns as the CurrentPatient is removed from the CurrentDataSet
                if (CurrentPatient <= TotalPatients)
                    for i=1:length(BiCluster{2})
                        if (BiCluster{2}(i) >= CurrentPatient)
                            BiCluster{2}(i) = BiCluster{2}(i) + 1;
                        end
                    end
                end

            elseif (AlgorithmSelection == 2)
            
                %%%%For CC Algorithm Delta is named as Beta (just for setting convenience)
                RemoveColumns = 1;
                Delta = Beta;                
                [BiCluster{1} BiCluster{2}] = CCAlgorithm2(CurrentDataSet, Delta, Alpha, RemoveColumns);
                
                %%%%Adjust the columns as the CurrentPatient is removed from the CurrentDataSet
                if (CurrentPatient <= TotalPatients)
                    for i=1:length(BiCluster{2})
                        if (BiCluster{2}(i) >= CurrentPatient)
                            BiCluster{2}(i) = BiCluster{2}(i) + 1;
                        end
                    end
                end
                
            end

            CurrentPatientBiClusters{CurrentPatient, RefGeneIndex} = BiCluster;            
            clear BiCluster;    
            RefGeneIndex = RefGeneIndex + 1;        
            
        end
                
    end

    AllBiClustersAllClasses{CurrentClass} = CurrentPatientBiClusters;
    clear CurrentPatientBiClusters;
    
end

%%%Save the generated bi-clusters in a file

save 'bkup.mat' AllBiClustersAllClasses -mat; %%%Used as a backup

if (DatasetNumber == 1)
        
    if (exist('AllBiClustersAllClasses_2_LEU_Dudoit.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_2_LEU_Dudoit');
        tempData = tempData.AllBiClustersAllClasses;
        [AllBiClustersAllClasses] = SaveBiclusters(UpdatingBiclusters, AlgorithmSelection, VaryingParameter, ParameterSelection, StartingReferenceGene, TotalReferenceGenes, TotalClasses, AllBiClustersAllClasses, tempData);
    end
    save 'AllBiClustersAllClasses_2_LEU_Dudoit.mat' AllBiClustersAllClasses -mat;

elseif (DatasetNumber == 2)

    if (exist('AllBiClustersAllClasses_2_Prostate_Tumor_Singh.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_2_Prostate_Tumor_Singh');
        tempData = tempData.AllBiClustersAllClasses;
        [AllBiClustersAllClasses] = SaveBiclusters(UpdatingBiclusters, AlgorithmSelection, VaryingParameter, ParameterSelection, StartingReferenceGene, TotalReferenceGenes, TotalClasses, AllBiClustersAllClasses, tempData);
    end
    save 'AllBiClustersAllClasses_2_Prostate_Tumor_Singh.mat' AllBiClustersAllClasses -mat;

elseif (DatasetNumber == 3)

    if (exist('AllBiClustersAllClasses_4_Brain_Tumor_Nutt.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_4_Brain_Tumor_Nutt');
        tempData = tempData.AllBiClustersAllClasses;
        [AllBiClustersAllClasses] = SaveBiclusters(UpdatingBiclusters, AlgorithmSelection, VaryingParameter, ParameterSelection, StartingReferenceGene, TotalReferenceGenes, TotalClasses, AllBiClustersAllClasses, tempData);
    end
    save 'AllBiClustersAllClasses_4_Brain_Tumor_Nutt.mat' AllBiClustersAllClasses -mat;

elseif (DatasetNumber == 4)

    if (exist('AllBiClustersAllClasses_5_Brain_Tumor_Pomeroy.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_5_Brain_Tumor_Pomeroy');
        tempData = tempData.AllBiClustersAllClasses;
        [AllBiClustersAllClasses] = SaveBiclusters(UpdatingBiclusters, AlgorithmSelection, VaryingParameter, ParameterSelection, StartingReferenceGene, TotalReferenceGenes, TotalClasses, AllBiClustersAllClasses, tempData);
    end
    save 'AllBiClustersAllClasses_5_Brain_Tumor_Pomeroy.mat' AllBiClustersAllClasses -mat;
    
elseif (DatasetNumber == 5)

    if (exist('AllBiClustersAllClasses_11_Tumor_Su.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_11_Tumor_Su');
        tempData = tempData.AllBiClustersAllClasses;
        [AllBiClustersAllClasses] = SaveBiclusters(UpdatingBiclusters, AlgorithmSelection, VaryingParameter, ParameterSelection, StartingReferenceGene, TotalReferenceGenes, TotalClasses, AllBiClustersAllClasses, tempData);
    end
    save 'AllBiClustersAllClasses_11_Tumor_Su.mat' AllBiClustersAllClasses -mat;

elseif (DatasetNumber == 6)
    
    if (exist('AllBiClustersAllClasses_14_Tumor_Ramaswamy.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_14_Tumor_Ramaswamy');
        tempData = tempData.AllBiClustersAllClasses;
        [AllBiClustersAllClasses] = SaveBiclusters(UpdatingBiclusters, AlgorithmSelection, VaryingParameter, ParameterSelection, StartingReferenceGene, TotalReferenceGenes, TotalClasses, AllBiClustersAllClasses, tempData);
    end
    save 'AllBiClustersAllClasses_14_Tumor_Ramaswamy.mat' AllBiClustersAllClasses -mat;

elseif (DatasetNumber == 7)
    
    if (exist('AllBiClustersAllClasses_2_Prognostic_Breast_Cancer.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_2_Prognostic_Breast_Cancer');
        tempData = tempData.AllBiClustersAllClasses;
        [AllBiClustersAllClasses] = SaveBiclusters(UpdatingBiclusters, AlgorithmSelection, VaryingParameter, ParameterSelection, StartingReferenceGene, TotalReferenceGenes, TotalClasses, AllBiClustersAllClasses, tempData);
    end
    save 'AllBiClustersAllClasses_2_Prognostic_Breast_Cancer.mat' AllBiClustersAllClasses -mat;

elseif (DatasetNumber == 8)
    
    if (exist('AllBiClustersAllClasses_2_Prognostic_AML_ALL.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_2_Prognostic_AML_ALL');
        tempData = tempData.AllBiClustersAllClasses;
        [AllBiClustersAllClasses] = SaveBiclusters(UpdatingBiclusters, AlgorithmSelection, VaryingParameter, ParameterSelection, StartingReferenceGene, TotalReferenceGenes, TotalClasses, AllBiClustersAllClasses, tempData);
    end
    save 'AllBiClustersAllClasses_2_Prognostic_AML_ALL.mat' AllBiClustersAllClasses -mat;

elseif (DatasetNumber == 9)
    
    if (exist('AllBiClustersAllClasses_2_Prognostic_Central_Nervous.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_2_Prognostic_Central_Nervous');
        tempData = tempData.AllBiClustersAllClasses;
        [AllBiClustersAllClasses] = SaveBiclusters(UpdatingBiclusters, AlgorithmSelection, VaryingParameter, ParameterSelection, StartingReferenceGene, TotalReferenceGenes, TotalClasses, AllBiClustersAllClasses, tempData);
    end
    save 'AllBiClustersAllClasses_2_Prognostic_Central_Nervous.mat' AllBiClustersAllClasses -mat;

elseif (DatasetNumber == 10)
    
    if (exist('AllBiClustersAllClasses_2_Prognostic_Prostate.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_2_Prognostic_Prostate');
        tempData = tempData.AllBiClustersAllClasses;
        [AllBiClustersAllClasses] = SaveBiclusters(UpdatingBiclusters, AlgorithmSelection, VaryingParameter, ParameterSelection, StartingReferenceGene, TotalReferenceGenes, TotalClasses, AllBiClustersAllClasses, tempData);
    end
    save 'AllBiClustersAllClasses_2_Prognostic_Prostate.mat' AllBiClustersAllClasses -mat;

elseif (DatasetNumber == 11)
    
    if (exist('AllBiClustersAllClasses_2_Diagnostic_Lung_Cancer.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_2_Diagnostic_Lung_Cancer');
        tempData = tempData.AllBiClustersAllClasses;
        [AllBiClustersAllClasses] = SaveBiclusters(UpdatingBiclusters, AlgorithmSelection, VaryingParameter, ParameterSelection, StartingReferenceGene, TotalReferenceGenes, TotalClasses, AllBiClustersAllClasses, tempData);
    end
    save 'AllBiClustersAllClasses_2_Diagnostic_Lung_Cancer.mat' AllBiClustersAllClasses -mat;

elseif (DatasetNumber == 12)
    
    if (exist('AllBiClustersAllClasses_2_Diagnostic_AML_ALL.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_2_Diagnostic_AML_ALL');
        tempData = tempData.AllBiClustersAllClasses;
        [AllBiClustersAllClasses] = SaveBiclusters(UpdatingBiclusters, AlgorithmSelection, VaryingParameter, ParameterSelection, StartingReferenceGene, TotalReferenceGenes, TotalClasses, AllBiClustersAllClasses, tempData);
    end
    save 'AllBiClustersAllClasses_2_Diagnostic_AML_ALL.mat' AllBiClustersAllClasses -mat;

elseif (DatasetNumber == 13)
    
    if (exist('AllBiClustersAllClasses_2_Diagnostic_Colon_Tumor.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_2_Diagnostic_Colon_Tumor');
        tempData = tempData.AllBiClustersAllClasses;
        [AllBiClustersAllClasses] = SaveBiclusters(UpdatingBiclusters, AlgorithmSelection, VaryingParameter, ParameterSelection, StartingReferenceGene, TotalReferenceGenes, TotalClasses, AllBiClustersAllClasses, tempData);
    end
    save 'AllBiClustersAllClasses_2_Diagnostic_Colon_Tumor.mat' AllBiClustersAllClasses -mat;

elseif (DatasetNumber == 14)
    
    if (exist('AllBiClustersAllClasses_2_Diagnostic_Prostate.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_2_Diagnostic_Prostate');
        tempData = tempData.AllBiClustersAllClasses;
        [AllBiClustersAllClasses] = SaveBiclusters(UpdatingBiclusters, AlgorithmSelection, VaryingParameter, ParameterSelection, StartingReferenceGene, TotalReferenceGenes, TotalClasses, AllBiClustersAllClasses, tempData);
    end
    save 'AllBiClustersAllClasses_2_Diagnostic_Prostate.mat' AllBiClustersAllClasses -mat;
end
