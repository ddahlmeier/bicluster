function [Matrix] = CCalgorithm(Matrix)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Program: CCalgorithm(Matrix)                                                                                                                                 %
%   Author: Baljeet Malhotra                                                                                                                                %
%   Date Created: Jan. 30, 2007                                                                                                                             %
%   Last modified: Feb. 10, 2007                                                                                                                            %
%   Input:                                                                                                                                                  %
%   Output:                                                                                                                                                 %
%   Example:                                                                                                                                                %
%   Comments: Cheng and Church's basic algorithm                                                                                                                                              %   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Flag = 1;

while(Flag == 1)
    
    [RowSize ColSize] = size(Matrix);

    for i=1:RowSize
        RowMeans(i,1) = mean(Matrix(i,:));
    end

    for i=1:ColSize
        ColMeans(i,1) = mean(Matrix(:,i));
    end

    MatrixMean = sum(mean(Matrix))/ColSize;

    SumRowCol = 0;

    LargestSumRow = 0;
    LargestSumRowIndex = 1;
    for i=1:RowSize
        SumRow = 0;
        for j=1:ColSize
            tempCal = (Matrix(i,j) - RowMeans(i,1) - ColMeans(j,1) + MatrixMean)^2;
            SumRowCol = SumRowCol + tempCal;
            SumRow = SumRow + tempCal;
        end
        if(SumRow > LargestSumRow)
            LargestSumRow = SumRow;
            LargestSumRowIndex = i;
        end
    end

    LargestSumCol = 0;
    LargestSumColIndex = 1;
    for i=1:ColSize
        SumCol = 0;
        for j=1:RowSize
            tempCal = (Matrix(j,i) - ColMeans(i,1) - RowMeans(j,1) + MatrixMean)^2;
            SumRowCol = SumRowCol + tempCal;
            SumCol = SumCol + tempCal;
        end
        if(SumCol > LargestSumCol)
            LargestSumCol = SumCol;
            LargestSumColIndex = i;
        end
    end

    if(LargestSumCol > LargestSumRow)
        Matrix(:,LargestSumColIndex) = [];    
    else
        Matrix(LargestSumRowIndex,:) = [];
    end
        
    if(SumRowCol < 50)
        Flag = 0;
    end
    SumRowCol
end
SumRowCol