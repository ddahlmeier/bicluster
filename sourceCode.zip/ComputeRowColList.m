function [RowList ColList] = ComputeRowColList(Rows, Cols)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Program: ComputeRowColList(Row, Col)                                                                                                                    %
%   Author: Baljeet Malhotra                                                                                                                                %
%   Date Created: Jan. 30, 2007                                                                                                                             %
%   Last modified: Feb. 10, 2007                                                                                                                            %
%   Input:                                                                                                                                                  %
%   Output:                                                                                                                                                 %
%   Example:                                                                                                                                                %
%   Comments:                                                                                                                                               %   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i=1:Rows
    RowList(i) = i;
end

for i=1:Cols
    ColList(i) = i;
end
