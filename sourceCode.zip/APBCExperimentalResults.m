dataset(1) = '2_LEU_Dudoit.mat'; (47 25 3571)
MND(delta = 0.35; alpha = 1.1), Total bi-clusters = 1, Accuracy = 97.22 
MSB(alpha = 0.4; beta = 0.45; gamma = 1.2; RefGeneSet = [1 2 3]), Total bi-clusters = 3, Accuracy = 98.61 
Combined algorithms accuracy = 97.22
-------------------------------------------------------------------------

dataset(3) = '4_Brain_Tumor_Nutt.mat'; (14 7 14 15 10367)
MND(delta = 300; alpha = 1.1), Total bi-clusters = 1, Accuracy = 88 
MSB(alpha = 0.4; beta = 0.45; gamma = 1.2; RefGeneSet = [1 2 3]), Total bi-clusters = 3, Accuracy = 92 
Combined algorithms accuracy = 88
-------------------------------------------------------------------------

dataset(5) = '11_Tumor_Su'; (27 8 26 23 12 11 7 26 6 14 14 12533)
MND(delta = 1100; alpha = 1.1), Total bi-clusters = 1, Accuracy = 91.95
MSB(alpha = 0.3; beta = 0.45; gamma = 1.2; RefGeneSet = [1 2]), Total bi-clusters = 2, Accuracy = 96.55
Combined algorithms accuracy = 91.95
-------------------------------------------------------------------------

dataset(7) = '2_Prognostic_Breast_Cancer.mat'; (32 44 23625)
MND(delta = 0.03; alpha = 1.1), Total bi-clusters = 1, Accuracy = 53.94 
MSB(alpha = 0.4; beta = 0.45; gamma = 1.2; RefGeneSet = [5]), Total bi-clusters = 3, Accuracy = 71.05 
Combined algorithms accuracy = 53.94
-------------------------------------------------------------------------

dataset(8) = '2_Prognostic_AML_ALL.mat'; (8 7 7129)
MND(delta = 5300; alpha = 1.1), Total bi-clusters = 1, Accuracy = 100 
MSB(alpha = 0.4; beta = 0.45, gamma = 1.2; RefGeneSet = [3 4 5]), Total bi-clusters = 3, Accuracy = 100 
Combined algorithms accuracy = 100
-------------------------------------------------------------------------

dataset(9) = '2_Prognostic_Central_Nervous.mat'; (21 39 7129)
MND(delta = 15000; alpha = 1.1), Total bi-clusters = 1, Accuracy = 40 
MSB(alpha = 0.3; beta = 0.45, gamma = 1.2; RefGeneSet = [6]), Total bi-clusters = 3, Accuracy = 53.33(d1) 66.66(d2) (with the new method), Accuracy = 66.66 (with the old method)
Combined algorithms accuracy = 40
-------------------------------------------------------------------------

dataset(10) = '2_Prognostic_Prostate.mat'; (8 13 12600)
MND(delta = 25; alpha = 1.1), Total bi-clusters = 1, Accuracy = 80.95 
MSB(alpha = 0.3 and 0.4; beta = 0.45, gamma = 1.2; RefGeneSet = [1 2]), Total bi-clusters = 4, Accuracy = 95.23 
Combined algorithms accuracy = 80.95
-------------------------------------------------------------------------

dataset(11) = '2_Diagnostic_Lung_Cancer.mat'; (31 150 12533)
MND(delta = 150; alpha = 1.1), Total bi-clusters = 1, Accuracy = 88.95
MSB(alpha = 0.3; beta = 0.45, gamma = 1.2; RefGeneSet = [5]), Total bi-clusters = , Accuracy = 84.53
Combined algorithms accuracy = 88.95
-------------------------------------------------------------------------

dataset(12) = '2_Diagnostic_AML_ALL.mat'; (47 25 7129)
MND(delta = 7000; alpha = 1.1), Total bi-clusters = 1, Accuracy = 94.44
MSB(alpha = 0.3; beta = 0.45, gamma = 1.2; RefGeneSet = [3]), Total bi-clusters = 1, Accuracy = 93.05
Combined algorithms accuracy = 94.44
-------------------------------------------------------------------------

dataset(13) = '2_Diagnostic_Colon_Tumor.mat'; (40 22 2000)
MND(delta = 700; alpha = 1.1), Total bi-clusters = 1, Accuracy = 50.00 
MSB(alpha = 0.3; beta = 0.45, gamma = 1.2; RefGeneSet = [4]), Total bi-clusters = 1, Accuracy = 77.41
Combined algorithms accuracy = 50.00
-------------------------------------------------------------------------

dataset(14) = '2_Diagnostic_Prostate.mat'; (77 59 12600)
MND(delta = 13.2; alpha = 1.1), Total bi-clusters = 1, Accuracy = 55.14
MSB(alpha = 0.3; beta = 0.45, gamma = 1.2; RefGeneSet = [2]), Total bi-clusters = 1, Accuracy = 75.73 
Combined algorithms accuracy = 55.14
-------------------------------------------------------------------------