function [BiRowList BiColList BiCluster] = CCalgorithm2(Matrix, Delta, Alpha, RemoveColumns)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Program: CCalgorithm1(Matrix, Delta, Alpha, RemoveColumns)                                                                                              %
%   Author: Baljeet Malhotra                                                                                                                                %
%   Date Created: Jan. 30, 2007                                                                                                                             %
%   Last modified: Feb. 10, 2007                                                                                                                            %
%   Input:                                                                                                                                                  %
%   Output:                                                                                                                                                 %
%   Example:                                                                                                                                                %
%   Comments:                                                                                                                                               %   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

BiRowList = 0;
BiColList = 0;
BiCluster = 0;

OriginalMatrix = Matrix;

[RowSize ColSize] = size(Matrix);

[RowList ColList] = ComputeRowColList(RowSize, ColSize);

ResidueScore = computeResidue(Matrix);

while(ResidueScore > Delta && RowSize > 0 && ColSize > 0) %Start of while loop
        
        %Start of removing rows
        for i=1:RowSize
            RowMeans(i,1) = mean(Matrix(i,:));
        end

        for i=1:ColSize
            ColMeans(i,1) = mean(Matrix(:,i));
        end
        
        MatrixMean = sum(mean(Matrix))/ColSize;

        RemoveRowList = zeros(1);
       
        Index = 1;
        for i=1:RowSize
            SumRow = 0;
            for j=1:ColSize
                tempCal = (Matrix(i,j) - RowMeans(i,1) - ColMeans(j,1) + MatrixMean)^2;
                SumRow = SumRow + tempCal;
            end
            
            if((SumRow/ColSize) > (ResidueScore*Alpha))
                RemoveRowList(Index) = i;
                Index = Index + 1;
            end
        end
        if(RemoveRowList(1) ~= 0)
            Matrix(RemoveRowList,:) = [];
            RowList(RemoveRowList) = [];
        end

        %End of removing rows

        %Start of removing columns

        [RowSize ColSize] = size(Matrix);

        if (RemoveColumns == 1 && RowSize > 0 && ColSize > 0)

            for i=1:RowSize
                RowMeans(i,1) = mean(Matrix(i,:));
            end

            for i=1:ColSize
                ColMeans(i,1) = mean(Matrix(:,i));
            end
            
            MatrixMean = sum(mean(Matrix))/ColSize;

            ResidueScore = computeResidue(Matrix);

            RemoveColList = zeros(1);

            Index = 1;
            for i=1:ColSize
                SumCol = 0;
                for j=1:RowSize
                    tempCal = (Matrix(j,i) - ColMeans(i,1) - RowMeans(j,1) + MatrixMean)^2;
                    SumCol = SumCol + tempCal;
                end
                if((SumCol/RowSize) > (ResidueScore*Alpha))
                    RemoveColList(Index) = i;
                    Index = Index + 1;
                end
            end        

            if(RemoveColList(1) ~= 0)
                Matrix(:,RemoveColList) = [];
                ColList(RemoveColList) = [];
            end
            
        end

        %End of removing columns

        [RowSize ColSize] = size(Matrix);
        ResidueScore = computeResidue(Matrix);
        
        if (RemoveColList(1) == 0 && RemoveRowList(1) == 0)
            disp('No rows or columns left to be deleted')
            break;
        end
        
end %End of while loop

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% CALLING CCALGORITHM1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (RowSize > 0 && ColSize > 0)
    disp('Switching to CCalgorithm1')
    [BiRowList BiColList BiCluster] = CCalgorithm1(Matrix, Delta, RowList, ColList, 1);
    if (BiRowList(1) ~= 0 && BiColList(1) ~= 0)
        %BiCluster
        BiClusterInActualMatrix = zeros(size(OriginalMatrix));
        BiClusterInActualMatrix(BiRowList, BiColList) = 100;
        %figure;
        %image(BiClusterInActualMatrix);
    else
        disp('Exiting CCalgorithm2: Reason: CCalgorithm1 failed.')
    end
    
else
    disp(strcat('RowSize: ',int2str(RowSize)))
    disp(strcat('ColSize: ',int2str(ColSize)))
    disp('Exiting CCalgorithm2: Reason: All rows or columns are deleted. Please check the parameters setting.')
end
