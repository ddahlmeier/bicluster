function [] = PrepareBiclusterFileTemplate()

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Program: PrepareBiclusterFileTemplate()                                                                                                         %
%   Author: Baljeet Malhotra                                                                                                                                %
%   Date Created: Feb. 14, 2007                                                                                                                             %
%   Last modified: Mar. 27, 2007                                                                                                                            %
%   Input:                                                                                                                                                  %
%   Output:                                                                                                                                                 %
%   Example:                                                                                                                                                %
%   Comments: Prepare template files for saving biclusters                    %   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;

for j = 1:5
    
    if (j == 1)
        Class=2;
    elseif (j == 2)
        Class=4;
    elseif (j == 3)
        Class=5;
    elseif (j == 4)
        Class=11;
    elseif (j == 5)
        Class=14;
    end
    
    a = [-100 -100];
    b{1} = a;
    b{2} = a;
    c{1,1} = b;
    c{2,1} = b;
    
    for i=1:Class %%%Classes
        d{i} = c;
    end
    for i=1:5 %%%Parameter selection
        e{i} = d;
    end
    for i=1:3 %%%Parameter
        f1{i} = e;
    end
    for i=1:2 %%%Parameter
        f2{i} = e;
    end
    %%%Algorithm
    g{1} = f1;
    g{2} = f2;
    AllBiClustersAllClasses = g;
  
    if (j == 1)
        save 'AllBiClustersAllClasses_2_Prognostic_Breast_Cancer.mat' AllBiClustersAllClasses -mat;
        save 'AllBiClustersAllClasses_2_Prognostic_AML_ALL.mat' AllBiClustersAllClasses -mat;
        save 'AllBiClustersAllClasses_2_Prognostic_Central_Nervous.mat' AllBiClustersAllClasses -mat;
        save 'AllBiClustersAllClasses_2_Prognostic_Prostate.mat' AllBiClustersAllClasses -mat;
        save 'AllBiClustersAllClasses_2_LEU_Dudoit.mat' AllBiClustersAllClasses -mat;
        save 'AllBiClustersAllClasses_2_Prostate_Tumor_Singh.mat' AllBiClustersAllClasses -mat;
        save 'AllBiClustersAllClasses_2_Diagnostic_Lung_Cancer.mat' AllBiClustersAllClasses -mat;
        save 'AllBiClustersAllClasses_2_Diagnostic_AML_ALL.mat' AllBiClustersAllClasses -mat;
        save 'AllBiClustersAllClasses_2_Diagnostic_Colon_Tumor.mat' AllBiClustersAllClasses -mat;
        save 'AllBiClustersAllClasses_2_Diagnostic_Prostate.mat' AllBiClustersAllClasses -mat;

    elseif (j == 2)
%         save 'AllBiClustersAllClasses_4_Brain_Tumor_Nutt.mat' AllBiClustersAllClasses -mat;
    elseif (j == 3)
%         save 'AllBiClustersAllClasses_5_Brain_Tumor_Pomeroy.mat' AllBiClustersAllClasses -mat;
    elseif (j == 4)
%         save 'AllBiClustersAllClasses_11_Tumor_Su.mat' AllBiClustersAllClasses -mat;
    elseif (j == 5)
%         save 'AllBiClustersAllClasses_2_Diagnostic_Prostate.mat' AllBiClustersAllClasses -mat;
    end
    
end

clear all;

