function [StartingReferenceGene] = PrepareReferenceGenesSelection(DatasetNumber, AlgorithmSelection, VaryingParameter, ParameterSelection)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Program: PrepareReferenceGenesSelection(DatasetNumber, AlgorithmSelection, VaryingParameter, ParameterSelection)                                        %
%   Author: Baljeet Malhotra                                                                                                                                %
%   Date Created: Feb. 14, 2007                                                                                                                             %
%   Last modified: Apr. 02, 2007                                                                                                                            %
%   Input:                                                                                                                                                  %
%   Output:                                                                                                                                                 %
%   Example:                                                                                                                                                %
%   Comments: Prepares selection of refernce genes for a particular dataset for generation of bi-clusters                                                   %   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

StartingReferenceGene = 0;

if (DatasetNumber == 1)
        
    if (exist('AllBiClustersAllClasses_2_LEU_Dudoit.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_2_LEU_Dudoit');
    end

elseif (DatasetNumber == 2)

    if (exist('AllBiClustersAllClasses_2_Prostate_Tumor_Singh.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_2_Prostate_Tumor_Singh');
    end

elseif (DatasetNumber == 3)

    if (exist('AllBiClustersAllClasses_4_Brain_Tumor_Nutt.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_4_Brain_Tumor_Nutt');
    end

elseif (DatasetNumber == 4)

    if (exist('AllBiClustersAllClasses_5_Brain_Tumor_Pomeroy.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_5_Brain_Tumor_Pomeroy');
    end
    
elseif (DatasetNumber == 5)

    if (exist('AllBiClustersAllClasses_11_Tumor_Su.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_11_Tumor_Su');
    end

elseif (DatasetNumber == 6)
    
    if (exist('AllBiClustersAllClasses_14_Tumor_Ramaswamy.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_14_Tumor_Ramaswamy');
    end

elseif (DatasetNumber == 7)
    
    if (exist('AllBiClustersAllClasses_2_Prognostic_Breast_Cancer.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_2_Prognostic_Breast_Cancer');
    end

elseif (DatasetNumber == 8)
    
    if (exist('AllBiClustersAllClasses_2_Prognostic_AML_ALL.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_2_Prognostic_AML_ALL');
    end

elseif (DatasetNumber == 9)
    
    if (exist('AllBiClustersAllClasses_2_Prognostic_Central_Nervous.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_2_Prognostic_Central_Nervous');
    end

elseif (DatasetNumber == 10)
    
    if (exist('AllBiClustersAllClasses_2_Prognostic_Prostate.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_2_Prognostic_Prostate');
    end

elseif (DatasetNumber == 11)
    
    if (exist('AllBiClustersAllClasses_2_Diagnostic_Lung_Cancer.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_2_Diagnostic_Lung_Cancer');
    end

elseif (DatasetNumber == 12)
    
    if (exist('AllBiClustersAllClasses_2_Diagnostic_AML_ALL.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_2_Diagnostic_AML_ALL');
    end

elseif (DatasetNumber == 13)
    
    if (exist('AllBiClustersAllClasses_2_Diagnostic_Colon_Tumor.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_2_Diagnostic_Colon_Tumor');
    end

elseif (DatasetNumber == 14)
    
    if (exist('AllBiClustersAllClasses_2_Diagnostic_Prostate.mat', 'file') == 2);
        tempData = load('AllBiClustersAllClasses_2_Diagnostic_Prostate');
    end

end

AllBiClustersAllClasses = tempData.AllBiClustersAllClasses;
[TotalPatients TotalRefGenes] = size(AllBiClustersAllClasses{AlgorithmSelection}{VaryingParameter}{ParameterSelection}{1});
StartingReferenceGene = TotalRefGenes + 1;
disp(strcat('Creating new data set for RefGene : ' , int2str(StartingReferenceGene)))
