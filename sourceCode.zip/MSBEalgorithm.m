function [BiClusterRows, BiClusterCols] = MSBEalgorithm(Matrix, Alpha, Beta, Gamma, GammaE, RefGene)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Program: MSBEalgorithm(Matrix, Alpha, Beta, Gamma, GammaE, RefGene)                                                                                     %
%   Author: Baljeet Malhotra                                                                                                                                %
%   Date Created: Jan. 30, 2007                                                                                                                             %
%   Last modified: Feb. 10, 2007                                                                                                                            %
%   Input:                                                                                                                                                  %
%   Output:                                                                                                                                                 %
%   Example:                                                                                                                                                %
%   Comments: Liu and Wang's Maximum Similarity Bicluster Algorithm With Extension                                                                          %   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[Row Col] = size(Matrix);

[BiClusterRows BiClusterCols] = MSBalgorithm(Matrix, Alpha, Beta, Gamma, RefGene);
SimilarityMatrix = ComputeSimilarityMatrix(Matrix, Alpha, Beta, Gamma, RefGene);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%(START) INCREMENTING THE BI-CLUSTER ROW BY ROW %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Index = length(BiClusterRows);
for i=1:Row
    RowSimilarityScore = 0;
    if (isempty(intersect(BiClusterRows, i)))        
        for j=1:length(BiClusterCols)
            RowSimilarityScore = RowSimilarityScore + SimilarityMatrix(i,BiClusterCols(j));
        end
        if (RowSimilarityScore >= GammaE*length(BiClusterCols))
            Index = Index + 1;
            BiClusterRows(Index) = i;
        end    
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%(END) INCREMENTING THE BI-CLUSTER ROW BY ROW %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
BiClusterInActualMatrix = zeros(size(Matrix));
BiClusterInActualMatrix(BiClusterRows, BiClusterCols) = 100;
figure;
image(BiClusterInActualMatrix);
