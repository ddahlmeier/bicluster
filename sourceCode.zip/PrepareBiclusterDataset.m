function [] = PrepareBiclusterDataset(DatasetNumber, StartingReferenceGene, TotalReferenceGenes, UpdatingBiclusters, Setting)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Program: PrepareBiclusterDataset(DatasetNumber, StartingReferenceGene, TotalReferenceGenes, UpdatingBiclusters, Setting)                                %
%   Author: Baljeet Malhotra                                                                                                                                %
%   Date Created: Feb. 14, 2007                                                                                                                             %
%   Last modified: Mar. 27, 2007                                                                                                                            %
%   Input:                                                                                                                                                  %
%   Output:                                                                                                                                                 %
%   Example:                                                                                                                                                %
%   Comments: Prepare biclusters with various settings for MSB and CC algorithms                                                                            %   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Parameter setting for bicluster generation

if (Setting == 1)

    AlgorithmSelection = 1;
    VaryingParameter = 1;
    ParameterSelection = 1

    %%% Seed

    Alpha = 0.3
    Beta =  0.45;
    Gamma = 1.2;
    
    TotalRun = 5;

    for Currentrun=1:TotalRun 

        GenerateBiclusters(DatasetNumber, AlgorithmSelection, VaryingParameter, ParameterSelection, StartingReferenceGene, TotalReferenceGenes, UpdatingBiclusters, Alpha, Beta, Gamma);
        ParameterSelection = ParameterSelection + 1
        Alpha = Alpha + 0.1    

    end

end
    
if (Setting == 2)

    AlgorithmSelection = 1;
    VaryingParameter = 2;
    ParameterSelection = 1

    %%% Seed

    Alpha = 0.4;
    Beta =  0.45;
    Gamma = 1.2;       
    
    TotalRun = 5;

    for Currentrun=1:TotalRun 

        GenerateBiclusters(DatasetNumber, AlgorithmSelection, VaryingParameter, ParameterSelection, StartingReferenceGene, TotalReferenceGenes, UpdatingBiclusters, Alpha, Beta, Gamma);
        ParameterSelection = ParameterSelection + 1
        Beta = Beta + 0.1    

    end

end
    
if (Setting == 3)

    AlgorithmSelection = 1;
    VaryingParameter = 3;
    ParameterSelection = 1

    %%% Seed

    Alpha = 0.4;
    Beta =  0.45;
    Gamma = 1.1;       
    
    TotalRun = 5;

    for Currentrun=1:TotalRun 

        GenerateBiclusters(DatasetNumber, AlgorithmSelection, VaryingParameter, ParameterSelection, StartingReferenceGene, TotalReferenceGenes, UpdatingBiclusters, Alpha, Beta, Gamma);
        ParameterSelection = ParameterSelection + 1
        Gamma = Gamma + 0.2    

    end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Generating biclusters with CC  Algorithm%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (Setting == 4) %%% Changing Beta

    AlgorithmSelection = 2;
    VaryingParameter = 1;
    ParameterSelection = 1
    TotalReferenceGenes = 1;

    %%% Seed
    %%%For CC algortihm Beta = Delta
    
    Beta =  0.20
    Alpha = 1.10;
    Gamma = 1.2;  %%%%It is just a dummy value, CC algorithm does not use this parameter
       
    TotalRun = 5;

    for Currentrun=1:TotalRun 

        GenerateBiclusters(DatasetNumber, AlgorithmSelection, VaryingParameter, ParameterSelection, StartingReferenceGene, TotalReferenceGenes, UpdatingBiclusters, Alpha, Beta, Gamma);
        ParameterSelection = ParameterSelection + 1
        Beta = Beta + 0.05    

    end

end

if (Setting == 5) %%%Changing Alpha

    AlgorithmSelection = 2;
    VaryingParameter = 2;
    ParameterSelection = 1
    TotalReferenceGenes = 1;

    %%% Seed
    %%%For CC algortihm Beta = Delta
    
    Beta =  0.20;
    Alpha = 1.10
    Gamma = 1.2;  %%%%It is just a dummy value, CC algorithm does not use this parameter
       
    TotalRun = 5;

    for Currentrun=1:TotalRun 

        GenerateBiclusters(DatasetNumber, AlgorithmSelection, VaryingParameter, ParameterSelection, StartingReferenceGene, TotalReferenceGenes, UpdatingBiclusters, Alpha, Beta, Gamma);
        ParameterSelection = ParameterSelection + 1
        Alpha = Alpha + 0.50    

    end

end