function [TotalSamplesCorrectlyClassified Accuracy] = RunBiclusterClassification(DatasetNumber, AlgorithmSelection, VaryingParameter, ParameterSelection, DistanceFuntion, StartingReferenceGene, TotalReferenceGenes)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Program: RunBiclusterClassification(DatasetNumber, AlgorithmSelection, VaryingParameter, ParameterSelection, DistanceFuntion, StartingReferenceGene, TotalReferenceGenes)    %
%   Author: Baljeet Malhotra                                                                                                                                                     %
%   Date Created: Feb. 14, 2007                                                                                                                                                  %
%   Last modified: July 9, 2007                                                                                                                                                  %
%   Input:                                                                                                                                                                       %
%   Output:                                                                                                                                                                      %
%   Example:                                                                                                                                                                     %
%   Comments: Classify new sample (gene expressions) based on MSB and CC Algorithms                                                                                              %    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Selection of bi-cluster dataset by loading bi-cluster files;

if (DatasetNumber == 1)       
    DatasetFileName = 'AllBiClustersAllClasses_2_LEU_Dudoit'        
elseif (DatasetNumber == 2)    
    DatasetFileName = 'AllBiClustersAllClasses_2_Prostate_Tumor_Singh'
elseif (DatasetNumber == 3)    
    DatasetFileName = 'AllBiClustersAllClasses_4_Brain_Tumor_Nutt'
elseif (DatasetNumber == 4)    
    DatasetFileName = 'AllBiClustersAllClasses_5_Brain_Tumor_Pomeroy'
elseif (DatasetNumber == 5)
    DatasetFileName = 'AllBiClustersAllClasses_11_Tumor_Su'
elseif (DatasetNumber == 6)
    DatasetFileName = 'AllBiClustersAllClasses_14_Tumor_Ramaswamy'
elseif (DatasetNumber == 7)
    DatasetFileName = 'AllBiClustersAllClasses_2_Prognostic_Breast_Cancer'
elseif (DatasetNumber == 8)
    DatasetFileName = 'AllBiClustersAllClasses_2_Prognostic_AML_ALL'
elseif (DatasetNumber == 9)
    DatasetFileName = 'AllBiClustersAllClasses_2_Prognostic_Central_Nervous'
elseif (DatasetNumber == 10)
    DatasetFileName = 'AllBiClustersAllClasses_2_Prognostic_Prostate'
elseif (DatasetNumber == 11)
    DatasetFileName = 'AllBiClustersAllClasses_2_Diagnostic_Lung_Cancer'
elseif (DatasetNumber == 12)
    DatasetFileName = 'AllBiClustersAllClasses_2_Diagnostic_AML_ALL'
elseif (DatasetNumber == 13)
    DatasetFileName = 'AllBiClustersAllClasses_2_Diagnostic_Colon_Tumor'
elseif (DatasetNumber == 14)
    DatasetFileName = 'AllBiClustersAllClasses_2_Diagnostic_Prostate'
end

%%%% Retreive all bi-clusters

AllBiClustersAllClasses = load(DatasetFileName);
AllBiClustersAllClasses = AllBiClustersAllClasses.AllBiClustersAllClasses;
AllBiClustersAllClasses = AllBiClustersAllClasses{AlgorithmSelection}{VaryingParameter}{ParameterSelection};

%%%% Selection of dataset by calling PrepareDataset program;

[AllSamplesAllClasses TotalClasses] = PrepareDataset(DatasetNumber);

TotalSamplesCorrectlyClassified = zeros(TotalClasses,2);

for CurrentTestingClass=1:TotalClasses %%%Start of all classes
    
    CurrentTestingClassDataset = AllSamplesAllClasses{CurrentTestingClass};
    [TotalGenes TotalSamplesInTestingClass] = size(CurrentTestingClassDataset);
    
    TotalSamplesCorrectlyClassified(CurrentTestingClass, 2) = TotalSamplesInTestingClass;
     
    for TestingSample=1:TotalSamplesInTestingClass %%%Start of all sample in a class

        CurrentTestingSample = CurrentTestingClassDataset(:, TestingSample);

        GlobalScore = zeros(TotalClasses,1);
        
        for CurrentLearningClass=1:TotalClasses
            
            CurrentLearningClassDataset = AllSamplesAllClasses{CurrentLearningClass};
            [TotalGenes TotalSamplesInLearningClass] = size(CurrentLearningClassDataset);

            for CurrentReferenceGene=StartingReferenceGene:TotalReferenceGenes
                            
                %%%Fetch the bi-cluster of current learning class                                
                if (CurrentTestingClass == CurrentLearningClass)
                    CurrentBiCluster = CurrentLearningClassDataset(AllBiClustersAllClasses{CurrentLearningClass}{TestingSample,CurrentReferenceGene}{1}, AllBiClustersAllClasses{CurrentLearningClass}{TestingSample,CurrentReferenceGene}{2});
                    %%%Truncate the current testing sample in order to
                    %%%select only those genes that have appeared in the
                    %%%biclusters of the corresponding class
                    CurrentMappedTestingSample = CurrentTestingSample(AllBiClustersAllClasses{CurrentLearningClass}{TestingSample,CurrentReferenceGene}{1});
                    
                else
                    CurrentBiCluster = CurrentLearningClassDataset(AllBiClustersAllClasses{CurrentLearningClass}{TotalSamplesInLearningClass+1,CurrentReferenceGene}{1}, AllBiClustersAllClasses{CurrentLearningClass}{TotalSamplesInLearningClass+1,CurrentReferenceGene}{2});
                    %%%Truncate the current testing sample in order to
                    %%%select only those genes that have appeared in the
                    %%%biclusters of the corresponding class
                    CurrentMappedTestingSample = CurrentTestingSample(AllBiClustersAllClasses{CurrentLearningClass}{TotalSamplesInLearningClass+1,CurrentReferenceGene}{1});
                end
                  
                %%%Computing the distance of testing sample from the
                %%%current bicluster of class1
                
                [R C] = size(CurrentBiCluster);                
                
                LocalScore = 0;               
                
                %%%%Selection of various distance function
                
                if (DistanceFuntion == 1) %%%%Average absolute distance of bicluster  
                    for i=1:R
                        for j=1:C
                            LocalScore = LocalScore + sqrt((CurrentBiCluster(i,j) - CurrentMappedTestingSample(i))^2);
                        end
                    end
                    LocalScore = LocalScore/(R*C);
                    
                elseif (DistanceFuntion == 2) %%%%Average euclidean distance of bicluster
                    for i=1:R
                        for j=1:C
                            LocalScore = LocalScore + (CurrentBiCluster(i,j) - CurrentMappedTestingSample(i))^2;
                        end
                    end
                    LocalScore = sqrt(LocalScore)/(R*C);

                elseif (DistanceFuntion == 3) %%%%Average euclidean distance of rows (genes)
                    for i=1:R
                        tempLocalScore = 0;
                        for j=1:C
                            tempLocalScore = tempLocalScore + (CurrentBiCluster(i,j) - CurrentMappedTestingSample(i))^2;
                        end
                        tempLocalScore = sqrt(tempLocalScore);
                        LocalScore = LocalScore + tempLocalScore;
                    end
                    LocalScore = LocalScore/R;
                    
                elseif (DistanceFuntion == 4) %%%%Average euclidean distance of columns (conditions)
                    for i=1:C
                        tempLocalScore = 0;
                        for j=1:R
                            tempLocalScore = tempLocalScore + (CurrentBiCluster(j,i) - CurrentMappedTestingSample(j))^2;
                        end
                        tempLocalScore = sqrt(tempLocalScore);
                        LocalScore = LocalScore + tempLocalScore;
                    end
                    LocalScore = LocalScore/C;

                end %%%%End of selection of distance funtion
                                    
                GlobalScore(CurrentLearningClass,1) = GlobalScore(CurrentLearningClass,1) + LocalScore;
                
            end
            
        end
        
        [MinScore MinScoreIndex] = min(GlobalScore);                
        
        if (MinScoreIndex == 1) %%%%Start of decision on the sample
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 1'))
            if(CurrentTestingClass == 1)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        elseif (MinScoreIndex == 2)
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 2'))
            if(CurrentTestingClass == 2)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        elseif (MinScoreIndex == 3)
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 3'))
            if(CurrentTestingClass == 3)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        elseif (MinScoreIndex == 4)
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 4'))
            if(CurrentTestingClass == 4)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        elseif (MinScoreIndex == 5)
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 5'))
            if(CurrentTestingClass == 5)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        elseif (MinScoreIndex == 6)
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 6'))
            if(CurrentTestingClass == 6)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        elseif (MinScoreIndex == 7)
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 7'))
            if(CurrentTestingClass == 7)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        elseif (MinScoreIndex == 8)
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 8'))
            if(CurrentTestingClass == 8)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        elseif (MinScoreIndex == 9)
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 9'))
            if(CurrentTestingClass == 9)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        elseif (MinScoreIndex == 10)
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 10'))
            if(CurrentTestingClass == 10)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        elseif (MinScoreIndex == 11)
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 11'))
            if(CurrentTestingClass == 11)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        elseif (MinScoreIndex == 12)
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 12'))
            if(CurrentTestingClass == 12)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        elseif (MinScoreIndex == 13)
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 13'))
            if(CurrentTestingClass == 13)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        elseif (MinScoreIndex == 14)
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 14'))
            if(CurrentTestingClass == 14)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        elseif (MinScoreIndex == 15)
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 15'))
            if(CurrentTestingClass == 15)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        elseif (MinScoreIndex == 16)
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 16'))
            if(CurrentTestingClass == 16)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        elseif (MinScoreIndex == 17)
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 17'))
            if(CurrentTestingClass == 17)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        elseif (MinScoreIndex == 18)
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 18'))
            if(CurrentTestingClass == 18)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        elseif (MinScoreIndex == 19)
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 19'))
            if(CurrentTestingClass == 19)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        elseif (MinScoreIndex == 20)
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 20'))
            if(CurrentTestingClass == 20)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        elseif (MinScoreIndex == 21)
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 21'))
            if(CurrentTestingClass == 21)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        elseif (MinScoreIndex == 22)
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 22'))
            if(CurrentTestingClass == 22)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        elseif (MinScoreIndex == 23)
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 23'))
            if(CurrentTestingClass == 23)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        elseif (MinScoreIndex == 24)
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 24'))
            if(CurrentTestingClass == 24)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        elseif (MinScoreIndex == 25)
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 25'))
            if(CurrentTestingClass == 25)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        elseif (MinScoreIndex == 26)
            disp(strcat(strcat((strcat('Testing Class : ' , int2str(CurrentTestingClass))), (strcat(' Sample : ' , int2str(TestingSample)))), ' belongs to Class 26'))
            if(CurrentTestingClass == 26)
                TotalSamplesCorrectlyClassified(CurrentTestingClass) = TotalSamplesCorrectlyClassified(CurrentTestingClass) + 1;
            end
        end%%%%End of decision on the sample
        
    end %%%End of all samples in a class
    
end %%%End of all classes

Accuracy = sum(TotalSamplesCorrectlyClassified);
Accuracy = (Accuracy(1)/Accuracy(2))*100;


                
            
        
        


            
            
