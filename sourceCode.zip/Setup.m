function [ResultSet] = Setup(Experiment, RefGene)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Program: Setup(Experiment, RefGene)                                                                                                                     %
%   Author: Baljeet Malhotra                                                                                                                                %
%   Date Created: Feb 09, 2007                                                                                                                              %
%   Last modified: Feb. 13, 2007                                                                                                                            %
%   Input:                                                                                                                                                  %
%   Output:                                                                                                                                                 %
%   Example:                                                                                                                                                %
%   Comments:                                                                                                                                               %   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (Experiment == 1)
    
    ResultSet = zeros(4);
    
    data = load('leu_data_type_1');
    Matrix = data.C1;
    Alpha = 0.45;
    Beta = 0.45;
    Gamma = 1.1;
    RefGene = 1257;
    [a] = MSBalgorithm(Matrix, Alpha, Beta, Gamma, RefGene)
    
    data = load('leu_data_type_2');
    Matrix = data.C2;
    Alpha = 0.45;
    Beta = 0.45;
    Gamma = 1.1;
    RefGene = 1257;
    [b] = MSBalgorithm(Matrix, Alpha, Beta, Gamma, RefGene)

    data = load('leu_data_type_1-and-2');
    Matrix = data.C3;
    Alpha = 0.45;
    Beta = 0.45;
    Gamma = 1.1;
    RefGene = 1257;
    [c] = MSBalgorithm(Matrix, Alpha, Beta, Gamma, RefGene)

    data = load('leu_data_type_1-and-2-mix');
    Matrix = data.C4;
    Alpha = 0.45;
    Beta = 0.45;
    Gamma = 1.1;
    RefGene = 1257;
    [d] = MSBalgorithm(Matrix, Alpha, Beta, Gamma, RefGene)

end


if (Experiment == 2)
    data = load('leu_data_type_1-and-2-mix');
    Matrix = data.C4;
    Alpha = 0.45;
    Beta = 0.45;
    Gamma = 1.2;
    GammaE = 1.1;
    [ResultSet] = MSBEalgorithm(Matrix, Alpha, Beta, Gamma, GammaE, RefGene);    
end


if (Experiment == 3)
    data = load('leu_data_type_1-and-2-mix');
    Matrix = data.C4;
    Alpha = 0.45;
    Beta = 0.45;
    Gamma = 1.1;
    GammaE = 1.2;
    RefCond = 2;
    [ResultSet] = AMSBEalgorithm(Matrix, Alpha, Beta, Gamma, GammaE, RefGene, RefCond);    
end


if (Experiment == 4)
    RefGene = [456 753 987 2300];
    data = load('leu_data_type_1-and-2-mix');
    Matrix = data.C4;
    Alpha = 0.45;
    Beta = 0.45;
    Gamma = 1.1;
    for i=1:length(RefGene)
        [ResultSet{i,1} ResultSet{i,2}] = MSBalgorithm(Matrix, Alpha, Beta, Gamma, RefGene(i));
    end
    
    disp('Results of intersection of genes')
    (intersect(ResultSet{1,1}, ResultSet{2,1}))
    (intersect(ResultSet{1,1}, ResultSet{3,1}))
    (intersect(ResultSet{1,1}, ResultSet{4,1}))    
    (intersect(ResultSet{2,1}, ResultSet{3,1}))
    (intersect(ResultSet{2,1}, ResultSet{4,1}))
    (intersect(ResultSet{3,1}, ResultSet{4,1}))
    
end


if (Experiment == 5)
    data = load('MSB_Sample_Data');
    Matrix = data.A;
    size(Matrix)
    Delta = 2;
    Alpha = 1.1;
    ResultSet = cell(1,3);
    [ResultSet{1,1} ResultSet{1,2}, ResultSet{1,3}] = CCalgorithm2(Matrix, Delta, Alpha, 1);
    disp('Results of intersection of genes')
    %figure(ResultSet{1,3})    
end

    