function [] = RunBiclusterAnalysis(DatasetNumber, Analysis)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Program: RunBiclusterAnalysis(DatasetNumber, Analysis)                                                                                                  %
%   Author: Baljeet Malhotra                                                                                                                                %
%   Date Created: Feb. 14, 2007                                                                                                                             %
%   Last modified: Mar. 27, 2007                                                                                                                            %
%   Input:                                                                                                                                                  %
%   Output:                                                                                                                                                 %
%   Example:                                                                                                                                                %
%   Comments:                                                                                                                                               %   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

AlgorithmSelection = 1;
StartVaryingParameter = 1;
EndVaryingParameter = 3;
StartParameterSelection = 2;
EndParameterSelection = 5;
TotalRefGenes = 19;

if (Analysis == 1)
       
    Option = 1;
    
    [CoverageAllClasses RefGenes] = AnalyzeBiclusters(DatasetNumber, AlgorithmSelection, StartVaryingParameter, EndVaryingParameter, StartParameterSelection, EndParameterSelection, TotalRefGenes, Option);
           
    save 'AllCoverageAllClasses_2_LEU_Dudoit_.mat' CoverageAllClasses -mat;
       
    %%%%%%% VARYING ALPHA
    
    %%%Gene coverage for class1 with changing Alpha
    
    Class = 1;
    VaryingParameter = 1;

    figure
    plot(RefGenes, CoverageAllClasses{Class}{VaryingParameter}{1}(:,1), 'bo-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{2}(:,1), 'b*-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{3}(:,1), 'b^-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{4}(:,1), 'bh-');
    title('Gene coverage for varying Alpha')
    xlabel('Number of reference genes');
    ylabel('Coverage (%)');
    axis([1 20 -5 80]);
    legend('Alpha=0.4', 'Alpha=0.5', 'Alpha=0.6', 'Alpha=0.7', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_1_Gene_Coverage_Varying_Alpha.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );
        
    %%%Gene coverage for class2 with changing Alpha

    Class = 2;
    VaryingParameter = 1;
    
    figure
    plot(RefGenes, CoverageAllClasses{Class}{VaryingParameter}{1}(:,1), 'bo-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{2}(:,1), 'b*-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{3}(:,1), 'b^-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{4}(:,1), 'bh-');
    title('Gene coverage for varying Alpha')
    xlabel('Number of reference genes');
    ylabel('Coverage (%)');
    axis([1 20 -5 80]);
    legend('Alpha=0.4', 'Alpha=0.5', 'Alpha=0.6', 'Alpha=0.7', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_2_Gene_Coverage_Varying_Alpha.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );

    %%%Condition coverage for class1 with changing Alpha

    Class = 1;
    VaryingParameter = 1;

    figure
    plot(RefGenes, CoverageAllClasses{Class}{VaryingParameter}{1}(:,2), 'bo-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{2}(:,2), 'b*-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{3}(:,2), 'b^-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{4}(:,2), 'bh-');
    title('Condition coverage for varying Alpha')
    xlabel('Number of reference genes');
    ylabel('Coverage (%)');
    axis([1 20 -5 140]);
    legend('Alpha=0.4', 'Alpha=0.5', 'Alpha=0.6', 'Alpha=0.7', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_1_Cond_Coverage_Varying_Alpha.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );

    %%%Condition coverage for class2 with changing Alpha
    
    Class = 2;
    VaryingParameter = 1;

    figure
    plot(RefGenes, CoverageAllClasses{Class}{VaryingParameter}{1}(:,2), 'bo-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{2}(:,2), 'b*-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{3}(:,2), 'b^-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{4}(:,2), 'bh-');
    title('Condition coverage for varying Alpha')
    xlabel('Number of reference genes');
    ylabel('Coverage (%)');
    axis([1 20 -5 140]);
    legend('Alpha=0.4', 'Alpha=0.5', 'Alpha=0.6', 'Alpha=0.7', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_2_Cond_Coverage_Varying_Alpha.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );    
    
    %%%%%%% VARYING BETA
        
     %%%Gene coverage for class1 with changing Beta
    
    Class = 1;
    VaryingParameter = 2;
    
    figure
    plot(RefGenes, CoverageAllClasses{Class}{VaryingParameter}{1}(:,1), 'bo-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{2}(:,1), 'b*-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{3}(:,1), 'b^-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{4}(:,1), 'bh-');
    title('Gene coverage for varying Beta')
    xlabel('Number of reference genes');
    ylabel('Coverage (%)');
    axis([1 20 -5 80]);
    legend('Beta=0.45', 'Beta=0.55', 'Beta=0.65', 'Beta=0.75', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_1_Gene_Coverage_Varying_Beta.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );
        
    %%%Gene coverage for class2 with changing Beta

    Class = 2;
    VaryingParameter = 2;
    
    figure
    plot(RefGenes, CoverageAllClasses{Class}{VaryingParameter}{1}(:,1), 'bo-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{2}(:,1), 'b*-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{3}(:,1), 'b^-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{4}(:,1), 'bh-');
    title('Gene coverage for varying Beta')
    xlabel('Number of reference genes');
    ylabel('Coverage (%)');
    axis([1 20 -5 80]);
    legend('Beta=0.45', 'Beta=0.55', 'Beta=0.65', 'Beta=0.75', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_2_Gene_Coverage_Varying_Beta.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );

    %%%Condition coverage for class1 with changing Beta

    Class = 1;
    VaryingParameter = 2;

    figure
    plot(RefGenes, CoverageAllClasses{Class}{VaryingParameter}{1}(:,2), 'bo-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{2}(:,2), 'b*-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{3}(:,2), 'b^-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{4}(:,2), 'bh-');
    title('Condition coverage for varying Beta')
    xlabel('Number of reference genes');
    ylabel('Coverage (%)');
    axis([1 20 -5 140]);
    legend('Beta=0.45', 'Beta=0.55', 'Beta=0.65', 'Beta=0.75', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_1_Cond_Coverage_Varying_Beta.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );

    %%%Condition coverage for class1 with changing Beta
    
    Class = 2;
    VaryingParameter = 2;

    figure
    plot(RefGenes, CoverageAllClasses{Class}{VaryingParameter}{1}(:,2), 'bo-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{2}(:,2), 'b*-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{3}(:,2), 'b^-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{4}(:,2), 'bh-');
    title('Condition coverage for varying Beta')
    xlabel('Number of reference genes');
    ylabel('Coverage (%)');
    axis([1 20 -5 140]);
    legend('Beta=0.45', 'Beta=0.55', 'Beta=0.65', 'Beta=0.75', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_2_Cond_Coverage_Varying_Beta.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );    
       
    %%%%%%% VARYING GAMMA    
    
    %%%Gene coverage for class1 with changing gamma
    
    Class = 1;
    VaryingParameter = 3;
    
    figure
    plot(RefGenes, CoverageAllClasses{Class}{VaryingParameter}{1}(:,1), 'bo-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{2}(:,1), 'b*-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{3}(:,1), 'b^-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{4}(:,1), 'bh-');
    title('Gene coverage for varying Gamma')
    xlabel('Number of reference genes');
    ylabel('Coverage (%)');
    axis([1 20 -5 140]);
    legend('Gamma=1.4', 'Gamma=1.6', 'Gamma=1.8', 'Gamma=1.10', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_1_Gene_Coverage_Varying_Gamma.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );
        
    %%%Gene coverage for class2 with changing gamma

    Class = 2;
    VaryingParameter = 3;
    
    figure
    plot(RefGenes, CoverageAllClasses{Class}{VaryingParameter}{1}(:,1), 'bo-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{2}(:,1), 'b*-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{3}(:,1), 'b^-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{4}(:,1), 'bh-');
    title('Gene coverage for varying Gamma')
    xlabel('Number of reference genes');
    ylabel('Coverage (%)');
    axis([1 20 -5 140]);
    legend('Gamma=1.4', 'Gamma=1.6', 'Gamma=1.8', 'Gamma=1.10', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_2_Gene_Coverage_Varying_Gamma.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );

    %%%Condition coverage for class1 with changing gamma

    Class = 1;
    VaryingParameter = 3;

    figure
    plot(RefGenes, CoverageAllClasses{Class}{VaryingParameter}{1}(:,2), 'bo-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{2}(:,2), 'b*-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{3}(:,2), 'b^-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{4}(:,2), 'bh-');
    title('Condition coverage for varying Gamma')
    xlabel('Number of reference genes');
    ylabel('Coverage (%)');
    axis([1 20 -5 140]);
    legend('Gamma=1.4', 'Gamma=1.6', 'Gamma=1.8', 'Gamma=1.10', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_1_Cond_Coverage_Varying_Gamma.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );

    %%%Condition coverage for class1 with changing gamma
    
    Class = 2;
    VaryingParameter = 3;

    figure
    plot(RefGenes, CoverageAllClasses{Class}{VaryingParameter}{1}(:,2), 'bo-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{2}(:,2), 'b*-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{3}(:,2), 'b^-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{4}(:,2), 'bh-');
    title('Condition coverage for varying Gamma')
    xlabel('Number of reference genes');
    ylabel('Coverage (%)');
    axis([1 20 -5 140]);
    legend('Gamma=1.4', 'Gamma=1.6', 'Gamma=1.8', 'Gamma=1.10', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_2_Cond_Coverage_Varying_Gamma.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );       
    

elseif (Analysis == 2)    
       
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Combined Coverage %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Combined Coverage %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%Coverage for class1 with changing Alpha
    Option = 1;
    Class = 1;
    VaryingParameter = 1;

    [CoverageAllClasses RefGenes] = AnalyzeBiclusters(DatasetNumber, AlgorithmSelection, StartVaryingParameter, EndVaryingParameter, StartParameterSelection, EndParameterSelection, TotalRefGenes, Option);
    
    figure
    plot(RefGenes, CoverageAllClasses{Class}{VaryingParameter}{1}(:,2));
    title('Gene coverage for varying Alpha')
    xlabel('Number of reference genes');
    ylabel('Coverage (%)');
    axis([1 50 -5 190]);
    legend('Alpha=0.9', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, 'temp.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );
    
    figure
    plot(RefGenes, CoverageAllClasses{Class}{VaryingParameter}{1}(:,3), 'bo-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{2}(:,3), 'b*-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{3}(:,3), 'b^-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{4}(:,3), 'bh-');
    title('Gene coverage for varying Alpha')
    xlabel('Number of reference genes');
    ylabel('Coverage (%)');
    axis([1 20 -5 80]);
    legend('Alpha=0.4', 'Alpha=0.5', 'Alpha=0.6', 'Alpha=0.7', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_1_Coverage_Varying_Alpha.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );
        
    %%%Coverage for class1 with changing Beta
    
    Class = 1;
    VaryingParameter = 2;

    figure
    plot(RefGenes, CoverageAllClasses{Class}{VaryingParameter}{1}(:,3), 'bo-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{2}(:,3), 'b*-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{3}(:,3), 'b^-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{4}(:,3), 'bh-');
    title('Gene coverage for varying Beta')
    xlabel('Number of reference genes');
    ylabel('Coverage (%)');
    axis([1 20 -5 80]);
    legend('Beta=0.45', 'Beta=0.55', 'Beta=0.65', 'Beta=0.75', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_1_Coverage_Varying_Beta.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );

    %%%Coverage for class1 with changing Gamma
    
    Class = 1;
    VaryingParameter = 3;

    figure
    plot(RefGenes, CoverageAllClasses{Class}{VaryingParameter}{1}(:,3), 'bo-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{2}(:,3), 'b*-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{3}(:,3), 'b^-', RefGenes, CoverageAllClasses{Class}{VaryingParameter}{4}(:,3), 'bh-');
    title('Gene coverage for varying Gamma')
    xlabel('Number of reference genes');
    ylabel('Coverage (%)');
    axis([1 20 -5 80]);
    legend('Gamma=1.3', 'Gamma=1.5', 'Gamma=1.7', 'Gamma=1.8', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_1_Coverage_Varying_Gamma.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );
    
    close all;


elseif (Analysis == 3)
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Overlapping %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Overlapping %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
    %%%Condition overlap for class1 for changing gamma
    
%     figure1 = figure; 
%     axes1 = axes(...
%       'CameraUpVector',[0 1 0],...
%       'XTick',[1 2 3],...
%       'XTickLabel',{'Fixed no. of random samples','Random no. of random samples', 'Fixed no. of fixed samples'},...
%       'Parent',figure1);
%     box('on');
%     hold('all');
%     bar(FalseOTHERPercentage');
%     title('Average Overlapping of biclusters');
%     xlabel('Number of neighborhoods');
%     ylabel('False negatives (% of total testing samples)');
%     legend('LFFT', 'LPSD', 'MFFT', 'MPSD', 'AMPSD', 'Location','Best', 'Orientation', 'verticle');
%     exportfig(gcf, 'FalseNegativesVaryingSampleSelectionApproach.eps', 'FontMode', 'fixed', 'FontSize', 12, 'color', 'cmyk' );    
    
    %%%VARYING ALPHA    

    %%%Gene overlap for class1 for changing Alpha    
    
    Option = 2;
    
    [CoverageAllClasses RefGenes] = AnalyzeBiclusters(DatasetNumber, AlgorithmSelection, StartVaryingParameter, EndVaryingParameter, StartParameterSelection, EndParameterSelection, TotalRefGenes, Option);

    save 'AllOverlapAllClasses_2_LEU_Dudoit_.mat' OverlapAllClasses -mat;

    figure
    plot(RefGenes, OverlapAllClasses{Class}{VaryingParameter}{1}(:,1), 'bo-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{2}(:,1), 'b*-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{3}(:,1), 'b^-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{4}(:,1), 'bh-');
    title('Gene Overlap for varying Alpha')
    xlabel('Number of reference genes');
    ylabel('Overlap (%)');
    axis([1 20 -5 80]);
    legend('Alpha=0.4', 'Alpha=0.5', 'Alpha=0.6', 'Alpha=0.7', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_1_Gene_Overlap_Varying_Alpha.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );
        
    %%%Gene Overlap for class2 with changing Alpha

    Class = 2;
    VaryingParameter = 1;
    
    figure
    plot(RefGenes, OverlapAllClasses{Class}{VaryingParameter}{1}(:,1), 'bo-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{2}(:,1), 'b*-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{3}(:,1), 'b^-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{4}(:,1), 'bh-');
    title('Gene Overlap for varying Alpha')
    xlabel('Number of reference genes');
    ylabel('Overlap (%)');
    axis([1 20 -5 80]);
    legend('Alpha=0.4', 'Alpha=0.5', 'Alpha=0.6', 'Alpha=0.7', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_2_Gene_Overlap_Varying_Alpha.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );

    %%%Condition Overlap for class1 with changing Alpha

    Class = 1;
    VaryingParameter = 1;

    figure
    plot(RefGenes, OverlapAllClasses{Class}{VaryingParameter}{1}(:,2), 'bo-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{2}(:,2), 'b*-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{3}(:,2), 'b^-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{4}(:,2), 'bh-');
    title('Condition Overlap for varying Alpha')
    xlabel('Number of reference genes');
    ylabel('Overlap (%)');
    axis([1 20 -5 140]);
    legend('Alpha=0.4', 'Alpha=0.5', 'Alpha=0.6', 'Alpha=0.7', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_1_Cond_Overlap_Varying_Alpha.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );

    %%%Condition Overlap for class2 with changing Alpha
    
    Class = 2;
    VaryingParameter = 1;

    figure
    plot(RefGenes, OverlapAllClasses{Class}{VaryingParameter}{1}(:,2), 'bo-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{2}(:,2), 'b*-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{3}(:,2), 'b^-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{4}(:,2), 'bh-');
    title('Condition Overlap for varying Alpha')
    xlabel('Number of reference genes');
    ylabel('Overlap (%)');
    axis([1 20 -5 140]);
    legend('Alpha=0.4', 'Alpha=0.5', 'Alpha=0.6', 'Alpha=0.7', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_2_Cond_Overlap_Varying_Alpha.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );    
    
    %%%%%%% VARYING BETA
        
     %%%Gene Overlap for class1 with changing Beta
    
    Class = 1;
    VaryingParameter = 2;
    
    figure
    plot(RefGenes, OverlapAllClasses{Class}{VaryingParameter}{1}(:,1), 'bo-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{2}(:,1), 'b*-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{3}(:,1), 'b^-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{4}(:,1), 'bh-');
    title('Gene Overlap for varying Beta')
    xlabel('Number of reference genes');
    ylabel('Overlap (%)');
    axis([1 20 -5 80]);
    legend('Beta=0.45', 'Beta=0.55', 'Beta=0.65', 'Beta=0.75', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_1_Gene_Overlap_Varying_Beta.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );
        
    %%%Gene Overlap for class2 with changing Beta

    Class = 2;
    VaryingParameter = 2;
    
    figure
    plot(RefGenes, OverlapAllClasses{Class}{VaryingParameter}{1}(:,1), 'bo-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{2}(:,1), 'b*-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{3}(:,1), 'b^-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{4}(:,1), 'bh-');
    title('Gene Overlap for varying Beta')
    xlabel('Number of reference genes');
    ylabel('Overlap (%)');
    axis([1 20 -5 80]);
    legend('Beta=0.45', 'Beta=0.55', 'Beta=0.65', 'Beta=0.75', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_2_Gene_Overlap_Varying_Beta.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );

    %%%Condition Overlap for class1 with changing Beta

    Class = 1;
    VaryingParameter = 2;

    figure
    plot(RefGenes, OverlapAllClasses{Class}{VaryingParameter}{1}(:,2), 'bo-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{2}(:,2), 'b*-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{3}(:,2), 'b^-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{4}(:,2), 'bh-');
    title('Condition Overlap for varying Beta')
    xlabel('Number of reference genes');
    ylabel('Overlap (%)');
    axis([1 20 -5 140]);
    legend('Beta=0.45', 'Beta=0.55', 'Beta=0.65', 'Beta=0.75', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_1_Cond_Overlap_Varying_Beta.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );

    %%%Condition Overlap for class1 with changing Beta
    
    Class = 2;
    VaryingParameter = 2;

    figure
    plot(RefGenes, OverlapAllClasses{Class}{VaryingParameter}{1}(:,2), 'bo-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{2}(:,2), 'b*-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{3}(:,2), 'b^-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{4}(:,2), 'bh-');
    title('Condition Overlap for varying Beta')
    xlabel('Number of reference genes');
    ylabel('Overlap (%)');
    axis([1 20 -5 140]);
    legend('Beta=0.45', 'Beta=0.55', 'Beta=0.65', 'Beta=0.75', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_2_Cond_Overlap_Varying_Beta.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );    
       
    %%%%%%% VARYING GAMMA    
    
    %%%Gene Overlap for class1 with changing gamma
    
    Class = 1;
    VaryingParameter = 3;
    
    figure
    plot(RefGenes, OverlapAllClasses{Class}{VaryingParameter}{1}(:,1), 'bo-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{2}(:,1), 'b*-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{3}(:,1), 'b^-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{4}(:,1), 'bh-');
    title('Gene Overlap for varying Gamma')
    xlabel('Number of reference genes');
    ylabel('Overlap (%)');
    axis([1 20 -5 140]);
    legend('Gamma=1.4', 'Gamma=1.6', 'Gamma=1.8', 'Gamma=1.10', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_1_Gene_Overlap_Varying_Gamma.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );
        
    %%%Gene Overlap for class2 with changing gamma

    Class = 2;
    VaryingParameter = 3;
    
    figure
    plot(RefGenes, OverlapAllClasses{Class}{VaryingParameter}{1}(:,1), 'bo-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{2}(:,1), 'b*-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{3}(:,1), 'b^-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{4}(:,1), 'bh-');
    title('Gene Overlap for varying Gamma')
    xlabel('Number of reference genes');
    ylabel('Overlap (%)');
    axis([1 20 -5 140]);
    legend('Gamma=1.4', 'Gamma=1.6', 'Gamma=1.8', 'Gamma=1.10', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_2_Gene_Overlap_Varying_Gamma.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );

    %%%Condition Overlap for class1 with changing gamma

    Class = 1;
    VaryingParameter = 3;

    figure
    plot(RefGenes, OverlapAllClasses{Class}{VaryingParameter}{1}(:,2), 'bo-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{2}(:,2), 'b*-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{3}(:,2), 'b^-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{4}(:,2), 'bh-');
    title('Condition Overlap for varying Gamma')
    xlabel('Number of reference genes');
    ylabel('Overlap (%)');
    axis([1 20 -5 140]);
    legend('Gamma=1.4', 'Gamma=1.6', 'Gamma=1.8', 'Gamma=1.10', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_1_Cond_Overlap_Varying_Gamma.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );

    %%%Condition Overlap for class1 with changing gamma
    
    Class = 2;
    VaryingParameter = 3;

    figure
    plot(RefGenes, OverlapAllClasses{Class}{VaryingParameter}{1}(:,2), 'bo-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{2}(:,2), 'b*-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{3}(:,2), 'b^-', RefGenes, OverlapAllClasses{Class}{VaryingParameter}{4}(:,2), 'bh-');
    title('Condition Overlap for varying Gamma')
    xlabel('Number of reference genes');
    ylabel('Overlap (%)');
    axis([1 20 -5 140]);
    legend('Gamma=1.4', 'Gamma=1.6', 'Gamma=1.8', 'Gamma=1.10', 'Location', 'NorthEast', 'Orientation', 'vertical');
    exportfig(gcf, '2_LEU_Dudoit_Class_2_Cond_Overlap_Varying_Gamma.eps', 'FontMode', 'fixed', 'FontSize', 14, 'color', 'cmyk' );
    
    close all;
    
end