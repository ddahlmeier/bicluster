function [GeneCoverage] = AnalyzeGenesSelection(DataSetNumber, AlgorithmSelection, ParameterSelection, ParameterValue, RefGene)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Program: AnalyzeGenesSelection(DataSetNumber, AlgorithmSelection, ParameterSelection, ParameterValue, RefGene)                                          %
%   Author: Baljeet Malhotra                                                                                                                                %
%   Date Created: Jan. 30, 2007                                                                                                                             %
%   Last modified: Feb. 10, 2007                                                                                                                            %
%   Input:                                                                                                                                                  %
%   Output:                                                                                                                                                 %
%   Example:                                                                                                                                                %
%   Comments:                                                                                                                                               %   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Class=2;
if (DataSetNumber == 1)
    tempfile1 = 'AllBiClustersAllClasses_2_LEU_Dudoit.mat';
    tempData = PrepareDataset(DataSetNumber);
    TotalGenes = length(tempData{1});
elseif (DataSetNumber == 3)
    Class=4;
    tempfile1 = 'AllBiClustersAllClasses_4_Brain_Tumor_Nutt.mat';
    tempData = PrepareDataset(DataSetNumber);
    TotalGenes = length(tempData{1});
elseif (DataSetNumber == 7)
    tempfile1 = 'AllBiClustersAllClasses_2_Prognostic_Breast_Cancer.mat';
    tempData = PrepareDataset(DataSetNumber);
    TotalGenes = length(tempData{1});
elseif (DataSetNumber == 8)
    tempfile1 = 'AllBiClustersAllClasses_2_Prognostic_AML_ALL.mat';
    tempData = PrepareDataset(DataSetNumber);
    TotalGenes = length(tempData{1});
elseif (DataSetNumber == 9)
    tempfile1 = 'AllBiClustersAllClasses_2_Prognostic_Central_Nervous.mat';
    tempData = PrepareDataset(DataSetNumber);
    TotalGenes = length(tempData{1});
elseif (DataSetNumber == 10)
    tempfile1 = 'AllBiClustersAllClasses_2_Prognostic_Prostate.mat';
    tempData = PrepareDataset(DataSetNumber);
    TotalGenes = length(tempData{1});
elseif (DataSetNumber == 11)
    tempfile1 = 'AllBiClustersAllClasses_2_Diagnostic_Lung_Cancer.mat';
    tempData = PrepareDataset(DataSetNumber);
    TotalGenes = length(tempData{1});
elseif (DataSetNumber == 12)
    tempfile1 = 'AllBiClustersAllClasses_2_Diagnostic_AML_ALL.mat';
    tempData = PrepareDataset(DataSetNumber);
    TotalGenes = length(tempData{1});
elseif (DataSetNumber == 13)
    tempfile1 = 'AllBiClustersAllClasses_2_Diagnostic_Colon_Tumor.mat';
    tempData = PrepareDataset(DataSetNumber);
    TotalGenes = length(tempData{1});
elseif (DataSetNumber == 14)
    tempfile1 = 'AllBiClustersAllClasses_2_Diagnostic_Prostate.mat';
    tempData = PrepareDataset(DataSetNumber);
    TotalGenes = length(tempData{1});
end

A = load(tempfile1);
A = A.AllBiClustersAllClasses;

if (AlgorithmSelection == 2)
    RefGene = 1;
end

GeneCoverage = 0;

% for i=1:30                                                         
% temp = temp + length(union(A{2}{1}{1}{1}{i,1}{1}, A{2}{1}{1}{2}{151,1}{1}))/12533;
% end
% temp = temp/30

for j=1:Class
    TotalPatient = length(A{AlgorithmSelection}{ParameterSelection}{ParameterValue}{j});
    if(j==1)
        for i=1:TotalPatient-1
            geneSet = union(A{AlgorithmSelection}{ParameterSelection}{ParameterValue}{1}{i,RefGene}{1}, A{AlgorithmSelection}{ParameterSelection}{ParameterValue}{2}{length(A{AlgorithmSelection}{ParameterSelection}{ParameterValue}{2}),RefGene}{1});
            GeneCoverage = GeneCoverage + (length(geneSet)/TotalGenes)*100;
            clear geneSet;
        end
    elseif(j==2)
        for i=1:TotalPatient-1
            geneSet = union(A{AlgorithmSelection}{ParameterSelection}{ParameterValue}{2}{i,RefGene}{1}, A{AlgorithmSelection}{ParameterSelection}{ParameterValue}{1}{length(A{AlgorithmSelection}{ParameterSelection}{ParameterValue}{1}),RefGene}{1});
            GeneCoverage = GeneCoverage + (length(geneSet)/TotalGenes)*100;
            clear geneSet;
        end
    end
end
GeneCoverage = GeneCoverage/(length(A{AlgorithmSelection}{ParameterSelection}{ParameterValue}{1}) + length(A{AlgorithmSelection}{ParameterSelection}{ParameterValue}{2}));