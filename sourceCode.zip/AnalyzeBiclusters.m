function [MetricAllClasses RefGenes] = AnalyzeBiclusters(DatasetNumber, AlgorithmSelection, StartVaryingParameter, EndVaryingParameter, StartParameterSelection, EndParameterSelection, TotalRefGenes, Option)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Program: AnalyzeBiclusters(DatasetNumber, AlgorithmSelection, StartVaryingParameter, EndVaryingParameter, StartParameterSelection, EndParameterSelection, TotalRefGenes, Option) %
%   Author: Baljeet Malhotra                                                                                                                                                         %
%   Date Created: Feb. 14, 2007                                                                                                                                                      %
%   Last modified: Mar. 27, 2007                                                                                                                                                     %
%   Input:                                                                                                                                                                           %
%   Output:                                                                                                                                                                          %
%   Example:                                                                                                                                                                         %
%   Comments:                                                                                                                                                                        %   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Selection of bi-cluster dataset by loading bi-cluster files;

if (DatasetNumber == 1)       
    DatasetFileName = 'AllBiClustersAllClasses_2_LEU_Dudoit'        
elseif (DatasetNumber == 2)    
    DatasetFileName = 'AllBiClustersAllClasses_2_Prostate_Tumor_Singh'
elseif (DatasetNumber == 3)    
    DatasetFileName = 'AllBiClustersAllClasses_4_Brain_Tumor_Nutt'
elseif (DatasetNumber == 4)    
    DatasetFileName = 'AllBiClustersAllClasses_5_Brain_Tumor_Pomeroy'
elseif (DatasetNumber == 5)
    DatasetFileName = 'AllBiClustersAllClasses_11_Tumor_Su'
elseif (DatasetNumber == 6)
    DatasetFileName = 'AllBiClustersAllClasses_14_Tumor_Ramaswamy'
end

%%%% Selection of dataset by calling PrepareDataset program;

[AllSamplesAllClasses TotalClasses] = PrepareDataset(DatasetNumber);

%%%Computing the coverage

if (Option == 1)
    
    for CurrentClass=1:TotalClasses %%%Start of all classes    
        CurrentDataset = AllSamplesAllClasses{CurrentClass};
        [TotalGenes TotalSamplesInClass] = size(CurrentDataset);

         %%%% Retreive all bi-clusters
         AllBiClustersAllClasses = load(DatasetFileName);
         AllBiClustersAllClasses = AllBiClustersAllClasses.AllBiClustersAllClasses; 
        
         VaryingParameterIndex = 1;   
         for CurrentVaryingParameter=StartVaryingParameter:EndVaryingParameter

            ParameterSelectionIndex = 1;
            for CurrentParameterSelection=StartParameterSelection:EndParameterSelection
                
                for CurrentRefGene=1:TotalRefGenes
%                     AlgorithmSelection
%                     CurrentVaryingParameter
%                     CurrentParameterSelection
%                     CurrentRefGene
%                     CurrentClass
                    BiClustersRows = AllBiClustersAllClasses{AlgorithmSelection}{CurrentVaryingParameter}{CurrentParameterSelection}{CurrentRefGene,CurrentClass}{1};
                    BiClustersCols = AllBiClustersAllClasses{AlgorithmSelection}{CurrentVaryingParameter}{CurrentParameterSelection}{CurrentRefGene,CurrentClass}{2};
                    if (CurrentRefGene == 1)
                        tempClusterRows = BiClustersRows;
                        tempClusterCols = BiClustersCols;
                    else
                        tempClusterRows = union(tempClusterRows, BiClustersRows);
                        tempClusterCols = union(tempClusterCols, BiClustersCols);
                    end
                    Coverage(CurrentRefGene,1) = (length(tempClusterRows)/TotalGenes)*100;
                    Coverage(CurrentRefGene,2) = (length(tempClusterCols)/TotalSamplesInClass)*100;                
                    Coverage(CurrentRefGene,3) = (Coverage(CurrentRefGene,1) + Coverage(CurrentRefGene,2))/2;
                    RefGenes(CurrentRefGene) = CurrentRefGene;
                end

                CoverageAllClasses{CurrentClass}{VaryingParameterIndex}{ParameterSelectionIndex} = Coverage;
                ParameterSelectionIndex = ParameterSelectionIndex + 1;
            end
            
            VaryingParameterIndex = VaryingParameterIndex + 1;            
         end         
         
    end
    
    MetricAllClasses = CoverageAllClasses;

%%%Computing the overlap

elseif (Option == 2)

    for CurrentClass=1:TotalClasses %%%Start of all classes    
        CurrentDataset = AllSamplesAllClasses{CurrentClass};
        [TotalGenes TotalSamplesInClass] = size(CurrentDataset);

         %%%% Retreive all bi-clusters
         AllBiClustersAllClasses = load(DatasetFileName);
         AllBiClustersAllClasses = AllBiClustersAllClasses.AllBiClustersAllClasses; 

         for CurrentVaryingParameter=StartVaryingParameter:EndVaryingParameter

            for CurrentParameterSelection=StartParameterSelection:EndParameterSelection

                EndRefGene = 2;            

                for i=1:(TotalRefGenes-1)

                    temp = 0;

                    RowOverlap = 0;
                    ColOverlap = 0;           

                    for CurrentRefGene=1:EndRefGene

                            BiClustersRows1 = AllBiClustersAllClasses{AlgorithmSelection}{CurrentVaryingParameter}{CurrentParameterSelection}{CurrentRefGene,CurrentClass}{1};
                            BiClustersCols1 = AllBiClustersAllClasses{AlgorithmSelection}{CurrentVaryingParameter}{CurrentParameterSelection}{CurrentRefGene,CurrentClass}{2};

                            for j=CurrentRefGene+1:EndRefGene

                                BiClustersRows2 = AllBiClustersAllClasses{AlgorithmSelection}{CurrentVaryingParameter}{CurrentParameterSelection}{j,CurrentClass}{1};
                                BiClustersCols2 = AllBiClustersAllClasses{AlgorithmSelection}{CurrentVaryingParameter}{CurrentParameterSelection}{j,CurrentClass}{2};

                                tempClusterRows = intersect(BiClustersRows1, BiClustersRows2);
                                tempClusterCols = intersect(BiClustersCols1, BiClustersCols2);

                                RowOverlap = RowOverlap + length(tempClusterRows)/((length(BiClustersRows1) + length(BiClustersRows2))/2);
                                ColOverlap = ColOverlap + length(tempClusterCols)/((length(BiClustersCols1) + length(BiClustersCols2))/2);

                                temp = temp + 1;

                            end

                    end

                    RefGenes(i) = EndRefGene;
                    Overlap(i,1) = RowOverlap/temp;
                    Overlap(i,2) = ColOverlap/temp;

                    EndRefGene = EndRefGene + 1;
                end

                OverlapAllClasses{CurrentClass}{CurrentVaryingParameter}{CurrentParameterSelection} = Overlap*100;

            end

         end

    end

    MetricAllClasses = OverlapAllClasses;
    
end %%%end of outer if (Option)