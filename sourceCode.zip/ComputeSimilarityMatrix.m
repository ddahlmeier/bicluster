function [SimilarityMatrix] = ComputeSimilarityMatrix(Matrix, Alpha, Beta, Gamma, RefGene)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Program: ComputeSimilarityMatrix(Matrix, Alpha, Beta, Gamma, RefGene)                                                                                   %
%   Author: Baljeet Malhotra                                                                                                                                %
%   Date Created: Jan. 30, 2007                                                                                                                             %
%   Last modified: Feb. 10, 2007                                                                                                                            %
%   Input:                                                                                                                                                  %
%   Output:                                                                                                                                                 %
%   Example:                                                                                                                                                %
%   Comments:                                                                                                                                               %   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[Row Col] = size(Matrix);

for i=1:Row
    for j=1:Col
        MatrixDavg(i,j) = abs(Matrix(i,j)-Matrix(RefGene,j));
    end
end
Davg = sum(sum(MatrixDavg))/(Row*Col);

SimilarityMatrix = zeros(Row, Col);

for i=1:Row
    for j=1:Col
        if (MatrixDavg(i,j) > (Alpha*Davg))
            SimilarityMatrix(i,j) = 0;
        else
            SimilarityMatrix(i,j) = 1 - (MatrixDavg(i,j)/(Alpha*Davg)) + Beta;
        end
    end
end