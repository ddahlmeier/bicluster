function [Residue] = computeResidue(Matrix)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Program: computeResidue(Matrix)                                                                                                                         %
%   Author: Baljeet Malhotra                                                                                                                                %
%   Date Created: Jan. 30, 2007                                                                                                                             %
%   Last modified: Feb. 10, 2007                                                                                                                            %
%   Input:                                                                                                                                                  %
%   Output:                                                                                                                                                 %
%   Example:                                                                                                                                                %
%   Comments:                                                                                                                                               %   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
[RowSize ColSize] = size(Matrix);

if (RowSize > 0 && ColSize > 0)

    for i=1:RowSize
        RowMeans(i,1) = mean(Matrix(i,:));
    end

    for i=1:ColSize
        ColMeans(i,1) = mean(Matrix(:,i));
    end

    MatrixMean = sum(mean(Matrix))/ColSize;

    SumRowCol = 0;

    for i=1:RowSize
        for j=1:ColSize
            tempCal = (Matrix(i,j) - RowMeans(i,1) - ColMeans(j,1) + MatrixMean)^2;
            SumRowCol = SumRowCol + tempCal;
        end
    end

    for i=1:ColSize
        for j=1:RowSize
            tempCal = (Matrix(j,i) - ColMeans(i,1) - RowMeans(j,1) + MatrixMean)^2;
            SumRowCol = SumRowCol + tempCal;
        end
    end

    Residue = SumRowCol/(RowSize*ColSize);

else
    Residue = -1;
    disp('Exiting computeResidue program. Error while computing residue score.')
end
